// TP2 sharding planner + verifier for the 27B groupwise artifact.
//
// Classifies every text object by name into a TP split role, applies rank-0/rank-1 sharding using
// the reader's authoritative planar geometry, byte-verifies a representative object of each split
// type against the full payload, and sums per-rank memory to confirm the model fits per GPU.
//
// Roles (world = 2):
//   ColumnN      : contiguous row split            (mlp/gate_up, output_head)
//   MultiRange*  : per-block row slices            (attn query_key/gate_value, gdn query_key/value_z)
//   RowK         : column (group) split + allreduce (attn output, gdn output, mlp/down)
//   Replicate    : full copy on every rank         (embedding, norms, a_log/dt_bias, conv, control)
#include "artifact/reader.h"
#include "core/multi_gpu/weight_shard.h"

#include <algorithm>
#include <cstdio>
#include <cstring>
#include <map>
#include <string>
#include <vector>

using namespace ninfer;
using namespace ninfer::artifact;
using namespace ninfer::multi_gpu;

namespace {

ShardGeometry to_shard(const RowSplitGeometry& g) {
    ShardGeometry s;
    s.rows               = g.rows;
    s.columns            = g.columns;
    s.group_size         = g.group_size;
    s.groups_per_row     = g.groups_per_row;
    s.low_bpg            = g.low_bytes_per_group;
    s.high_bpg           = g.high_bytes_per_group;
    s.low_plane_bytes    = g.low_plane_bytes;
    s.high_plane_offset  = g.high_plane_offset;
    s.high_plane_bytes   = g.high_plane_bytes;
    s.scale_plane_offset = g.scale_plane_offset;
    s.scale_plane_bytes  = g.scale_plane_bytes;
    s.encoded_bytes      = g.encoded_bytes;
    return s;
}

enum class Role {
    ColumnN,
    MultiRangeQK,
    MultiRangeGV,
    MultiRangeGQK,
    MultiRangeGZ,
    RowK,
    Replicate,
    Skip,
};

struct Plan {
    Role role;
    std::vector<RowRange> ranges;  // per-rank blocks (rank-0 starts)
};

// Block boundaries come from the hybrid 27B head layout:
//   attention: q 24x256=6144, kv 4x256=1024 (head_dim 256)
//   gdn:       q/k 16x128=2048 each, v/z 48x128=6144 each (head_dim 128)
Plan classify(const std::string& name) {
    Plan p;
    std::string rel = name;
    {
        auto a = name.find("text/layers/");
        if (a != std::string::npos) {
            auto b = name.find('/', a + 12);
            rel = (b == std::string::npos) ? std::string{} : name.substr(b + 1);
        }
    }
    if (name == "text/token_embedding") { p.role = Role::Replicate; return p; }
    if (name == "text/output_head")       { p.role = Role::ColumnN; return p; }
    if (name == "text/final_norm")        { p.role = Role::Replicate; return p; }
    if (name.rfind("draft_head", 0) == 0 || name.rfind("mtp/", 0) == 0) {
        p.role = Role::Skip;
        return p;
    }
    if (rel == "mlp/gate_up") { p.role = Role::ColumnN; return p; }
    if (rel == "mlp/down") { p.role = Role::RowK; return p; }
    if (rel == "attention/query_key") {
        p.role   = Role::MultiRangeQK;
        p.ranges = {{0, 3072}, {6144, 512}};  // rank0: q[0:3072], k[6144:7168]
        return p;
    }
    if (rel == "attention/gate_value") {
        p.role   = Role::MultiRangeGV;
        p.ranges = {{0, 3072}, {6144, 512}};
        return p;
    }
    if (rel == "attention/output") { p.role = Role::RowK; return p; }
    if (rel == "gdn/query_key") {
        p.role   = Role::MultiRangeGQK;
        p.ranges = {{0, 1024}, {2048, 1024}};
        return p;
    }
    if (rel == "gdn/value_z") {
        p.role   = Role::MultiRangeGZ;
        p.ranges = {{0, 3072}, {6144, 3072}};
        return p;
    }
    if (rel == "gdn/output") { p.role = Role::RowK; return p; }
    if (name.rfind("text/", 0) == 0) { p.role = Role::Replicate; return p; }
    p.role = Role::Skip;
    return p;
}

std::vector<RowRange> rank_ranges(const Plan& p, int rank) {
    std::vector<RowRange> out = p.ranges;
    for (auto& rr : out) rr.src_row0 += static_cast<std::uint64_t>(rank) * rr.count;
    return out;
}

bool verify_columnn(const unsigned char* full, const ShardGeometry& src,
                    const std::vector<RowRange>& r0, const std::vector<RowRange>& r1,
                    unsigned char* d0, unsigned char* d1, const ShardGeometry& dst0,
                    const ShardGeometry& dst1) {
    const std::uint64_t gpr = src.groups_per_row;
    std::vector<std::pair<int, std::uint64_t>> owner(src.rows);
    for (std::uint64_t i = 0; i < src.rows; ++i) owner[i] = {-1, 0};
    auto fill = [&](const std::vector<RowRange>& rr, int rank) {
        std::uint64_t local = 0;
        for (auto& R : rr)
            for (std::uint64_t j = 0; j < R.count; ++j) owner[R.src_row0 + j] = {rank, local++};
    };
    fill(r0, 0);
    fill(r1, 1);
    const unsigned char* plane[2] = {d0, d1};
    const ShardGeometry* dst[2]   = {&dst0, &dst1};
    for (std::uint64_t i = 0; i < src.rows; ++i) {
        int rank;
        std::uint64_t lr;
        std::tie(rank, lr) = owner[i];
        if (rank < 0) {
            std::printf("    row %llu unowned\n", (unsigned long long)i);
            return false;
        }
        if (std::memcmp(full + i * gpr * src.low_bpg, plane[rank] + lr * gpr * src.low_bpg,
                        gpr * src.low_bpg) != 0) {
            std::printf("    low mismatch row %llu\n", (unsigned long long)i);
            return false;
        }
        if (src.high_bpg > 0) {
            const unsigned char* sh = full + src.high_plane_offset + i * gpr * src.high_bpg;
            const unsigned char* dh = plane[rank] + dst[rank]->high_plane_offset +
                                      lr * gpr * src.high_bpg;
            if (std::memcmp(sh, dh, gpr * src.high_bpg) != 0) {
                std::printf("    high mismatch row %llu\n", (unsigned long long)i);
                return false;
            }
        }
        if (std::memcmp(full + src.scale_plane_offset + i * gpr * 2,
                        plane[rank] + dst[rank]->scale_plane_offset + lr * gpr * 2,
                        gpr * 2) != 0) {
            std::printf("    scale mismatch row %llu\n", (unsigned long long)i);
            return false;
        }
    }
    return true;
}

bool verify_rowk(const unsigned char* full, const ShardGeometry& src, unsigned char* d0,
                 unsigned char* d1, const ShardGeometry& dst) {
    const std::uint64_t gpr = src.groups_per_row;
    const std::uint64_t gr  = gpr / 2;
    const unsigned char* plane[2] = {d0, d1};
    for (std::uint64_t i = 0; i < src.rows; ++i) {
        for (std::uint64_t g = 0; g < gr; ++g) {
            const unsigned char* s0 = full + (i * gpr + g) * src.low_bpg;
            const unsigned char* s1 = full + (i * gpr + gr + g) * src.low_bpg;
            const unsigned char* e0 = plane[0] + (i * gr + g) * src.low_bpg;
            const unsigned char* e1 = plane[1] + (i * gr + g) * src.low_bpg;
            if (std::memcmp(s0, e0, src.low_bpg) != 0 || std::memcmp(s1, e1, src.low_bpg) != 0) {
                std::printf("    low rowk mismatch row %llu g %llu\n", (unsigned long long)i,
                            (unsigned long long)g);
                return false;
            }
            if (src.high_bpg > 0) {
                const unsigned char* h0 = full + src.high_plane_offset + (i * gpr + g) * src.high_bpg;
                const unsigned char* h1 = full + src.high_plane_offset + (i * gpr + gr + g) * src.high_bpg;
                const unsigned char* e0h =
                    plane[0] + dst.high_plane_offset + (i * gr + g) * src.high_bpg;
                const unsigned char* e1h =
                    plane[1] + dst.high_plane_offset + (i * gr + g) * src.high_bpg;
                if (std::memcmp(h0, e0h, src.high_bpg) != 0 ||
                    std::memcmp(h1, e1h, src.high_bpg) != 0) {
                    std::printf("    high rowk mismatch row %llu g %llu\n", (unsigned long long)i,
                                (unsigned long long)g);
                    return false;
                }
            }
            if (std::memcmp(full + src.scale_plane_offset + (i * gpr + g) * 2,
                            plane[0] + dst.scale_plane_offset + (i * gr + g) * 2, 2) != 0 ||
                std::memcmp(full + src.scale_plane_offset + (i * gpr + gr + g) * 2,
                            plane[1] + dst.scale_plane_offset + (i * gr + g) * 2, 2) != 0) {
                std::printf("    scale rowk mismatch row %llu g %llu\n", (unsigned long long)i,
                            (unsigned long long)g);
                return false;
            }
        }
    }
    return true;
}

}  // namespace

int main(int argc, char** argv) {
    const std::string path = argc > 1 ? argv[1] : "/home/intel/models/qwen3_6_27b.ninfer";
    Reader reader(path);
    const auto& objs = reader.objects();
    std::map<std::string, std::size_t> name_to_idx;
    for (std::size_t i = 0; i < objs.size(); ++i) {
        if (auto* t = std::get_if<TensorDescriptor>(&objs[i])) name_to_idx[t->name] = i;
    }

    // 1) Geometry cross-check: my ShardGeometry math vs the reader's authoritative geometry.
    {
        const auto* t = std::get_if<TensorDescriptor>(&objs[name_to_idx["text/layers/0/mlp/gate_up"]]);
        RowSplitGeometry rg = row_split_geometry(t->format, t->shape);
        ShardGeometry mg    = row_split_geometry(t->shape[0], t->shape[1], rg.group_size,
                                                 rg.low_bytes_per_group, rg.high_bytes_per_group);
        const bool geom_ok = (rg.high_plane_offset == mg.high_plane_offset) &&
                             (rg.scale_plane_offset == mg.scale_plane_offset) &&
                             (rg.encoded_bytes == mg.encoded_bytes) &&
                             (rg.groups_per_row == mg.groups_per_row);
        std::printf("geometry cross-check (gate_up Q4G64): reader enc=%llu soff=%llu | mine enc=%llu "
                    "soff=%llu | match=%s\n",
                    (unsigned long long)rg.encoded_bytes, (unsigned long long)rg.scale_plane_offset,
                    (unsigned long long)mg.encoded_bytes, (unsigned long long)mg.scale_plane_offset,
                    geom_ok ? "YES" : "NO");
        if (!geom_ok) {
            std::printf("TP2 SHARD PLAN FAIL (geometry mismatch)\n");
            return 1;
        }
    }

    // 2) Per-rank memory over all text objects (MTP-off, vision excluded).
    std::uint64_t rank_bytes = 0, skip_bytes = 0;
    std::map<std::string, std::uint64_t> by_role;
    for (std::size_t i = 0; i < objs.size(); ++i) {
        const auto* t = std::get_if<TensorDescriptor>(&objs[i]);
        if (!t) continue;
        Plan p = classify(t->name);
        if (p.role == Role::Skip) {
            skip_bytes += t->bytes;
            continue;
        }
        std::uint64_t rb;
        if (p.role == Role::Replicate) {
            rb = t->bytes;
        } else {
            RowSplitGeometry rg = row_split_geometry(t->format, t->shape);
            std::uint64_t rows_r, cols_r;
            if (p.role == Role::RowK) {
                rows_r = rg.rows;
                cols_r = rg.columns / 2;
            } else if (p.role == Role::ColumnN) {
                rows_r = rg.rows / 2;
                cols_r = rg.columns;
            } else {
                std::uint64_t r = 0;
                for (auto& R : p.ranges) r += R.count;
                rows_r = r;
                cols_r = rg.columns;
            }
            rb = row_split_geometry(rows_r, cols_r, rg.group_size, rg.low_bytes_per_group,
                                    rg.high_bytes_per_group)
                     .encoded_bytes;
        }
        rank_bytes += rb;
        by_role[std::to_string(static_cast<int>(p.role))] += rb;
    }
    std::printf("=== per-rank memory (text, MTP-off) ===\n");
    for (auto& [k, v] : by_role) std::printf("  role %-4s %8.2f MB\n", k.c_str(), v / 1e6);
    std::printf("  TOTAL per rank: %.2f GB   (skipped mtp+draft: %.2f GB)\n", rank_bytes / 1e9,
                skip_bytes / 1e9);
    const bool fits = rank_bytes < (std::uint64_t)16 * 1024 * 1024 * 1024;
    std::printf("  fits in 16 GiB per GPU? %s\n\n", fits ? "YES" : "NO");

    // 3) Byte-verify one object per split type against the real payload.
    struct VerifyCase {
        const char* name;
        bool rowk;
    };
    const VerifyCase cases[] = {
        {"text/layers/3/attention/query_key", false},
        {"text/layers/0/gdn/value_z", false},
        {"text/layers/0/mlp/gate_up", false},
        {"text/layers/0/mlp/down", true},
        {"text/layers/3/attention/output", true},
    };
    int vfail = 0;
    for (auto& c : cases) {
        auto it = name_to_idx.find(c.name);
        if (it == name_to_idx.end()) {
            std::printf("  [verify] %s MISSING\n", c.name);
            ++vfail;
            continue;
        }
        const auto* t = std::get_if<TensorDescriptor>(&objs[it->second]);
        const auto span = reader.payload(std::string_view(t->name));
        RowSplitGeometry rg = row_split_geometry(t->format, t->shape);
        ShardGeometry mg    = to_shard(rg);
        unsigned char* full = new unsigned char[span.data.size()];
        std::memcpy(full, span.data.data(), span.data.size());
        unsigned char* d0 = new unsigned char[span.data.size()];
        unsigned char* d1 = new unsigned char[span.data.size()];
        Plan p = classify(c.name);
        bool ok = false;
        if (c.rowk) {
            ShardOutput o0 = shard_row_split(full, mg, SplitSpec::RowK, 0, 2, d0, span.data.size(), 0);
            ShardOutput o1 = shard_row_split(full, mg, SplitSpec::RowK, 1, 2, d1, span.data.size(), 0);
            ok = verify_rowk(full, mg, d0, d1, o0.geom);
        } else if (p.role == Role::ColumnN) {
            const std::uint64_t half = mg.rows / 2;
            auto r0 = std::vector<RowRange>{{0, half}};
            auto r1 = std::vector<RowRange>{{half, half}};
            ShardOutput o0 = shard_row_split(full, mg, SplitSpec::ColumnN, 0, 2, d0, span.data.size(), 0);
            ShardOutput o1 = shard_row_split(full, mg, SplitSpec::ColumnN, 1, 2, d1, span.data.size(), 0);
            ok = verify_columnn(full, mg, r0, r1, d0, d1, o0.geom, o1.geom);
        } else {
            auto r0 = rank_ranges(p, 0);
            auto r1 = rank_ranges(p, 1);
            ShardOutput o0 = shard_row_ranges(full, mg, r0, d0, span.data.size(), 0);
            ShardOutput o1 = shard_row_ranges(full, mg, r1, d1, span.data.size(), 0);
            ok = verify_columnn(full, mg, r0, r1, d0, d1, o0.geom, o1.geom);
        }
        std::printf("  [verify] %-40s %s  (full enc %llu)\n", c.name, ok ? "PASS" : "FAIL",
                    (unsigned long long)mg.encoded_bytes);
        delete[] full;
        delete[] d0;
        delete[] d1;
        if (!ok) ++vfail;
    }

    const bool pass = (vfail == 0) && fits;
    std::printf("\nTP2 SHARD PLAN %s\n", pass ? "PASS" : "FAIL");
    return pass ? 0 : 1;
}
