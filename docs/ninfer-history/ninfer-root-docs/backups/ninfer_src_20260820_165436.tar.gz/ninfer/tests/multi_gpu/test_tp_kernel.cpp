// GPU numeric validation of the generic TP W8G32 GEMV against a CPU reference:
//   out[n,t] = sum_k  int8(n,k) * fp16scale(n,k/32) * bf16x(k,t)
// Builds a synthetic RowSplit W8G32_F16S weight (low plane + scale plane), runs
// tp_gemv for a few decode shapes, and compares against an fp64 reference rounded
// to bf16. Tolerance: bf16 is ~3 decimal digits; accumulate in fp64 and allow a small
// relative error since the GPU path accumulates in fp32.
#include "core/multi_gpu/tp_kernel.h"
#include "core/multi_gpu/weight_shard.h"
#include "core/tensor.h"

#include <cuda_bf16.h>
#include <cuda_fp16.h>
#include <cuda_runtime.h>

#include <cmath>
#include <cstdint>
#include <cstdio>
#include <random>
#include <vector>

using namespace ninfer;
using namespace ninfer::multi_gpu;

namespace {

bool check_cuda(cudaError_t e, const char* what) {
    if (e != cudaSuccess) {
        std::printf("  CUDA error at %s: %s\n", what, cudaGetErrorString(e));
        return false;
    }
    return true;
}

struct CpuWeight {
    std::vector<std::int8_t> low;   // [n, k]
    std::vector<std::uint16_t> scale_bits;  // [n, k/32] fp16 bits
    std::uint64_t scale_offset    = 0;
    std::uint64_t total_bytes     = 0;
};

CpuWeight make_weight(int n, int k, unsigned seed) {
    std::mt19937 rng(seed);
    std::uniform_int_distribution<int> byte_dist(0, 255);
    std::uniform_real_distribution<float> scale_dist(0.01f, 0.5f);
    CpuWeight w;
    w.low.resize(static_cast<size_t>(n) * k);
    const int gpr = k / 32;
    w.scale_bits.resize(static_cast<size_t>(n) * gpr);
    for (auto& b : w.low) {
        b = static_cast<std::int8_t>(byte_dist(rng) - 128);
    }
    for (auto& s : w.scale_bits) {
        s = __half_as_ushort(__float2half(scale_dist(rng)));
    }
    ShardGeometry geom = row_split_geometry(n, k, 32, 32, 0);
    w.scale_offset = geom.scale_plane_offset;
    w.total_bytes  = geom.encoded_bytes;
    return w;
}

bool run_case(int n, int k, int t, unsigned seed) {
    CpuWeight w = make_weight(n, k, seed);
    const int gpr = k / 32;

    // x: [k, t] bf16, random in [-1, 1]
    std::mt19937 rng(seed + 1);
    std::uniform_real_distribution<float> dist(-1.f, 1.f);
    std::vector<__nv_bfloat16> h_x(static_cast<size_t>(k) * t);
    for (auto& v : h_x) {
        v = __float2bfloat16(dist(rng));
    }

    // Host reference (fp64 accumulation, bf16 round). Layout matches the tuned kernel:
    //   x[tt, kk]   at tt*k + kk   (k contiguous)
    //   out[tt, nn] at tt*n + nn   (n contiguous, W8ContiguousOutput leading_dim = n)
    std::vector<__nv_bfloat16> ref(static_cast<size_t>(n) * t);
    for (int r = 0; r < n; ++r) {
        for (int tt = 0; tt < t; ++tt) {
            double acc = 0.0;
            for (int c = 0; c < k; ++c) {
                const float sc = __half2float(
                    __ushort_as_half(w.scale_bits[static_cast<size_t>(r) * gpr + c / 32]));
                acc += static_cast<double>(w.low[static_cast<size_t>(r) * k + c]) *
                       static_cast<double>(sc) *
                       static_cast<double>(__bfloat162float(h_x[static_cast<size_t>(tt) * k + c]));
            }
            ref[static_cast<size_t>(tt) * n + r] = __float2bfloat16(static_cast<float>(acc));
        }
    }

    // Device: weight payload (low + scale), x, out
    void* d_payload = nullptr;
    if (!check_cuda(cudaMalloc(&d_payload, w.total_bytes), "malloc payload")) return false;
    if (!check_cuda(cudaMemcpy(d_payload, w.low.data(), w.low.size(), cudaMemcpyHostToDevice),
                    "copy low")) {
        return false;
    }
    if (!check_cuda(cudaMemcpy(static_cast<char*>(d_payload) + w.scale_offset,
                               w.scale_bits.data(), w.scale_bits.size() * 2,
                               cudaMemcpyHostToDevice),
                    "copy scale")) {
        return false;
    }
    void* d_x = nullptr;
    if (!check_cuda(cudaMalloc(&d_x, h_x.size() * 2), "malloc x")) return false;
    if (!check_cuda(cudaMemcpy(d_x, h_x.data(), h_x.size() * 2, cudaMemcpyHostToDevice), "copy x"))
        return false;
    void* d_out = nullptr;
    if (!check_cuda(cudaMalloc(&d_out, ref.size() * 2), "malloc out")) return false;

    Weight weight;
    weight.qtype   = QType::W8G32_F16S;
    weight.group   = 32;
    weight.n       = n;
    weight.k       = k;
    weight.payload = d_payload;
    weight.payload_bytes = w.total_bytes;
    weight.qdata   = d_payload;                        // low plane at offset 0
    weight.scales  = static_cast<char*>(d_payload) + w.scale_offset;
    weight.padded_shape[1] = k;                        // padded_k (k already %32==0)

    Tensor x;
    x.dtype = DType::BF16;
    x.ne[0] = k;
    x.ne[1] = t;
    x.ne[2] = 1;
    x.ne[3] = 1;
    x.data  = d_x;

    Tensor out;
    out.dtype = DType::BF16;
    out.ne[0] = n;
    out.ne[1] = t;
    out.ne[2] = 1;
    out.ne[3] = 1;
    out.data  = d_out;

    tp_gemv(x, weight, out, 0);
    if (!check_cuda(cudaStreamSynchronize(0), "sync")) return false;

    std::vector<__nv_bfloat16> got(ref.size());
    if (!check_cuda(cudaMemcpy(got.data(), d_out, got.size() * 2, cudaMemcpyDeviceToHost),
                    "copy out")) {
        return false;
    }

    int bad = 0;
    double max_rel = 0.0;
    for (size_t i = 0; i < got.size(); ++i) {
        const float g = __bfloat162float(got[i]);
        const float r = __bfloat162float(ref[i]);
        const double rel =
            std::abs(g - r) / (std::abs(r) + 1e-6);
        if (rel > max_rel) max_rel = rel;
        // bf16 + fp32 accumulation: 1% relative; near-zero sums from cancellation get an
        // absolute floor (fp32-vs-fp64 noise on sums whose magnitude is far below the term
        // magnitudes).
        if (std::abs(g - r) > std::max(1e-2, 1e-2 * std::abs(r))) {
            ++bad;
            if (bad <= 3) {
                std::printf("    mismatch idx %zu got %.6f ref %.6f\n", i, g, r);
            }
        }
    }
    cudaFree(d_payload);
    cudaFree(d_x);
    cudaFree(d_out);

    const bool ok = bad == 0;
    std::printf("  [%d x %d, T=%d] %s  bad=%d max_rel=%.2e\n", n, k, t, ok ? "PASS" : "FAIL", bad,
                max_rel);
    return ok;
}
}  // namespace

int main() {
    int n_dev = 0;
    if (cudaGetDeviceCount(&n_dev) != cudaSuccess || n_dev < 1) {
        std::printf("SKIP: no GPU\n");
        return 77;
    }
    bool ok = true;
    // Small + real decode k. k must be multiple of 32.
    ok &= run_case(128, 128, 1, 101);
    ok &= run_case(256, 5120, 1, 202);   // O-proj / down decode shape family
    ok &= run_case(17408, 5120, 1, 303); // gate_up local (large n)
    ok &= run_case(5120, 3072, 4, 404);  // RowK local k, T=4 (MTP batch)

    // Bandwidth probe: time the big gate_up-local GEMV (reads ~90 MB of weight bytes).
    {
        const int n = 17408, k = 5120, t = 1;
        CpuWeight w = make_weight(n, k, 777);
        void* d_payload = nullptr;
        cudaMalloc(&d_payload, w.total_bytes);
        cudaMemcpy(d_payload, w.low.data(), w.low.size(), cudaMemcpyHostToDevice);
        cudaMemcpy(static_cast<char*>(d_payload) + w.scale_offset, w.scale_bits.data(),
                   w.scale_bits.size() * 2, cudaMemcpyHostToDevice);
        std::vector<__nv_bfloat16> h_x(k, __float2bfloat16(0.1f));
        void* d_x = nullptr, *d_out = nullptr;
        cudaMalloc(&d_x, k * 2);
        cudaMemcpy(d_x, h_x.data(), k * 2, cudaMemcpyHostToDevice);
        cudaMalloc(&d_out, n * 2);
        Weight weight;
        weight.qtype = QType::W8G32_F16S; weight.group = 32;
        weight.n = n; weight.k = k; weight.payload = d_payload;
        weight.payload_bytes = w.total_bytes;
        weight.qdata = d_payload;
        weight.scales = static_cast<char*>(d_payload) + w.scale_offset;
        weight.padded_shape[1] = k;
        Tensor x; x.dtype = DType::BF16; x.ne[0] = k; x.ne[1] = t; x.ne[2] = 1; x.ne[3] = 1; x.data = d_x;
        Tensor out; out.dtype = DType::BF16; out.ne[0] = n; out.ne[1] = t; out.ne[2] = 1; out.ne[3] = 1; out.data = d_out;
        tp_gemv(x, weight, out, 0);  // warmup
        cudaEvent_t e0, e1;
        cudaEventCreate(&e0); cudaEventCreate(&e1);
        cudaEventRecord(e0, 0);
        for (int i = 0; i < 20; ++i) tp_gemv(x, weight, out, 0);
        cudaEventRecord(e1, 0);
        cudaEventSynchronize(e1);
        float ms = 0.f;
        cudaEventElapsedTime(&ms, e0, e1);
        const double gb = (static_cast<double>(n) * k + static_cast<double>(n) * (k / 32) * 2) / 1e9;
        std::printf("  BW probe [%d x %d T=%d]: %.1f us/call  %.1f GB/s effective (HBM roofline ~427)\n",
                    n, k, t, ms / 20.f * 1000.f, gb / (ms / 20.f / 1000.f));
        cudaEventDestroy(e0); cudaEventDestroy(e1);
        cudaFree(d_payload); cudaFree(d_x); cudaFree(d_out);
    }
    std::printf(ok ? "TP_KERNEL TEST PASS\n" : "TP_KERNEL TEST FAIL\n");
    return ok ? 0 : 1;
}
