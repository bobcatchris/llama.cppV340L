// Validates the multi-GPU foundation (TpGroup): NCCL allreduce + point-to-point on 2 GPUs.
// Requires 2 free GPUs (run during a GPU window). Exits 0 on pass, 1 on fail.
#include "core/multi_gpu/tp_group.h"

#include <cuda_bf16.h>
#include <cuda_runtime.h>

#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <vector>

using namespace ninfer;
using namespace ninfer::multi_gpu;

namespace {
bool check_allreduce(TpGroup& g) {
    const int n = g.size();
    const std::size_t elems = 4096;
    std::vector<void*> ptrs(static_cast<std::size_t>(n), nullptr);
    for (int r = 0; r < n; ++r) {
        DeviceArena& a = g.make_arena(r, elems * 2 * 4);
        Tensor t = a.alloc(DType::BF16, {static_cast<int>(elems)});
        ptrs[static_cast<std::size_t>(r)] = t.data;
        cudaPointerAttributes attr{};
        if (cudaPointerGetAttributes(&attr, t.data) == cudaSuccess) {
            std::printf("  [diag] rank %d buf %p device=%d type=%d\n", r, t.data, attr.device, attr.type);
        } else {
            std::printf("  [diag] rank %d buf %p INVALID POINTER\n", r, t.data);
        }
    }
    for (int r = 0; r < n; ++r) {
        cudaSetDevice(g.device_of(r));
        std::vector<__nv_bfloat16> h(elems, __float2bfloat16(static_cast<float>(r + 1)));  // rank r -> r+1
        cudaMemcpy(ptrs[static_cast<std::size_t>(r)], h.data(), elems * 2, cudaMemcpyHostToDevice);
        cudaDeviceSynchronize();
        if (getenv("TPGROUP_DEBUG")) std::fprintf(stderr, "[test] rank %d H2D done\n", r);
    }
    g.allreduce_bf16(ptrs, elems);
    if (getenv("TPGROUP_DEBUG")) std::fprintf(stderr, "[test] allreduce returned\n");
    g.synchronize_all();
    if (getenv("TPGROUP_DEBUG")) std::fprintf(stderr, "[test] sync returned\n");
    const float expected = 1.0f + 2.0f;  // 2 ranks: 1 + 2
    for (int r = 0; r < n; ++r) {
        cudaSetDevice(g.device_of(r));
        std::vector<__nv_bfloat16> h(elems);
        cudaMemcpy(h.data(), ptrs[static_cast<std::size_t>(r)], elems * 2, cudaMemcpyDeviceToHost);
        for (std::size_t i = 0; i < elems; ++i) {
            if (std::fabs(__bfloat162float(h[i]) - expected) > 1e-3f) {
                std::printf("  allreduce MISMATCH rank=%d i=%zu got=%.4f want=%.4f\n", r, i,
                            __bfloat162float(h[i]), expected);
                return false;
            }
        }
    }
    return true;
}

bool check_p2p(TpGroup& g) {
    const int n = g.size();
    if (n < 2) {
        return true;
    }
    const std::size_t elems = 2048;
    const int src = 0, dst = 1;
    DeviceArena& as = g.make_arena(src, elems * 2 * 4);
    DeviceArena& ad = g.make_arena(dst, elems * 2 * 4);
    Tensor ts = as.alloc(DType::BF16, {static_cast<int>(elems)});
    Tensor td = ad.alloc(DType::BF16, {static_cast<int>(elems)});
    cudaSetDevice(g.device_of(src));
    std::vector<__nv_bfloat16> h(elems, __float2bfloat16(7.5f));
    cudaMemcpy(ts.data, h.data(), elems * 2, cudaMemcpyHostToDevice);
    cudaDeviceSynchronize();
    // Enqueue send (src) then recv (dst); both async on their streams, execute concurrently.
    g.send(ts.data, elems * 2, src, dst);
    g.recv(td.data, elems * 2, dst, src);
    g.synchronize_all();
    cudaSetDevice(g.device_of(dst));
    std::vector<__nv_bfloat16> out(elems);
    cudaMemcpy(out.data(), td.data, elems * 2, cudaMemcpyDeviceToHost);
    for (std::size_t i = 0; i < elems; ++i) {
        if (std::fabs(__bfloat162float(out[i]) - 7.5f) > 1e-3f) {
            std::printf("  p2p MISMATCH i=%zu got=%.4f want=7.5\n", i, __bfloat162float(out[i]));
            return false;
        }
    }
    return true;
}
}  // namespace

int main() {
    std::printf("TpGroup test: initializing on devices {0,1}...\n");
    TpGroupOptions opts;
    opts.devices = {0, 1};
    TpGroup group(opts);
    std::printf("  comms up (size=%d)\n", group.size());

    bool ok = true;
    std::printf("allreduce_bf16: ");
    if (check_allreduce(group)) {
        std::printf("PASS\n");
    } else {
        std::printf("FAIL\n");
        ok = false;
    }
    std::printf("p2p send/recv: ");
    if (check_p2p(group)) {
        std::printf("PASS\n");
    } else {
        std::printf("FAIL\n");
        ok = false;
    }
    std::printf(ok ? "TPGROUP TEST PASS\n" : "TPGROUP TEST FAIL\n");
    return ok ? 0 : 1;
}
