// Host-side validation of quantized weight sharding: shard a groupwise row-split weight into
// 2 ranks and verify the shards reconstruct the original bit-exactly (ColumnN + RowK).
// No GPU required (uses host buffers + cudaMemcpyAsync on the default stream).
#include "core/multi_gpu/weight_shard.h"

#include <cuda_runtime.h>

#include <cstdio>
#include <cstring>
#include <vector>

using namespace ninfer::multi_gpu;

namespace {
// Fill a buffer with a deterministic byte pattern.
void fill_pattern(unsigned char* p, std::size_t n, unsigned seed) {
    for (std::size_t i = 0; i < n; ++i) {
        p[i] = static_cast<unsigned char>(((i * 7 + seed) * 31) & 0xFFu);
    }
}

bool check_plane(const unsigned char* src, std::uint64_t src_off, const unsigned char* dst,
                 std::uint64_t dst_off, std::uint64_t bytes, const char* what) {
    if (bytes == 0) {
        return true;
    }
    if (std::memcmp(src + src_off, dst + dst_off, bytes) != 0) {
        std::printf("    plane mismatch: %s\n", what);
        return false;
    }
    return true;
}

// Verify ColumnN reconstruction: rank0 rows [0,R/2) + rank1 rows [R/2,R) == source, per plane.
bool verify_column_n(const unsigned char* src, const ShardGeometry& sg,
                     const unsigned char* r0, const ShardGeometry& g0, const unsigned char* r1,
                     const ShardGeometry& g1) {
    const std::uint64_t half_groups = (sg.rows / 2) * sg.groups_per_row;
    bool ok = true;
    ok &= check_plane(src, 0, r0, 0, half_groups * sg.low_bpg, "low r0");
    ok &= check_plane(src, half_groups * sg.low_bpg, r1, 0, half_groups * sg.low_bpg, "low r1");
    if (sg.high_bpg > 0) {
        ok &= check_plane(src, sg.high_plane_offset, r0, g0.high_plane_offset,
                          half_groups * sg.high_bpg, "high r0");
        ok &= check_plane(src, sg.high_plane_offset + half_groups * sg.high_bpg, r1,
                          g1.high_plane_offset, half_groups * sg.high_bpg, "high r1");
    }
    ok &= check_plane(src, sg.scale_plane_offset, r0, g0.scale_plane_offset, half_groups * 2,
                      "scale r0");
    ok &= check_plane(src, sg.scale_plane_offset + half_groups * 2, r1, g1.scale_plane_offset,
                      half_groups * 2, "scale r1");
    return ok;
}

// Verify RowK reconstruction: per row, rank0 groups [0,gpr/2) + rank1 [gpr/2,gpr) == source.
bool verify_row_k(const unsigned char* src, const ShardGeometry& sg, const unsigned char* r0,
                  const ShardGeometry& g0, const unsigned char* r1, const ShardGeometry& g1) {
    const std::uint64_t gpr = sg.groups_per_row;
    const std::uint64_t gpr_r = gpr / 2;
    bool ok = true;
    for (std::uint64_t i = 0; i < sg.rows && ok; ++i) {
        const std::uint64_t srow = i * gpr;
        const std::uint64_t drow = i * gpr_r;
        ok &= check_plane(src, srow * sg.low_bpg, r0, drow * g0.low_bpg, gpr_r * sg.low_bpg,
                          "low r0");
        ok &= check_plane(src, (srow + gpr_r) * sg.low_bpg, r1, drow * g1.low_bpg,
                          gpr_r * sg.low_bpg, "low r1");
        if (sg.high_bpg > 0) {
            ok &= check_plane(src, sg.high_plane_offset + srow * sg.high_bpg, r0,
                              g0.high_plane_offset + drow * g0.high_bpg, gpr_r * sg.high_bpg,
                              "high r0");
            ok &= check_plane(src, sg.high_plane_offset + (srow + gpr_r) * sg.high_bpg, r1,
                              g1.high_plane_offset + drow * g1.high_bpg, gpr_r * sg.high_bpg,
                              "high r1");
        }
        ok &= check_plane(src, sg.scale_plane_offset + srow * 2, r0,
                          g0.scale_plane_offset + drow * 2, gpr_r * 2, "scale r0");
        ok &= check_plane(src, sg.scale_plane_offset + (srow + gpr_r) * 2, r1,
                          g1.scale_plane_offset + drow * 2, gpr_r * 2, "scale r1");
    }
    return ok;
}
}  // namespace

int main() {
    // Q5G64: group 64, low 32 B, high 8 B. Shape [rows=64, cols=256] -> gpr=4.
    const std::uint64_t rows = 64, cols = 256, group = 64, low_bpg = 32, high_bpg = 8;
    ShardGeometry sg = row_split_geometry(rows, cols, group, low_bpg, high_bpg);
    std::vector<unsigned char> src(sg.encoded_bytes);
    fill_pattern(src.data(), src.size(), 1234);

    const int nr = 2;
    std::vector<unsigned char> buf0(sg.encoded_bytes), buf1(sg.encoded_bytes);
    cudaStream_t stream = 0;  // default stream; H2H copies
    bool ok = true;

    // ColumnN
    ShardOutput o0 = shard_row_split(src.data(), sg, SplitSpec::ColumnN, 0, nr, buf0.data(),
                                     buf0.size(), stream);
    ShardOutput o1 = shard_row_split(src.data(), sg, SplitSpec::ColumnN, 1, nr, buf1.data(),
                                     buf1.size(), stream);
    cudaStreamSynchronize(stream);
    std::printf("ColumnN: ");
    if (verify_column_n(src.data(), sg, buf0.data(), o0.geom, buf1.data(), o1.geom)) {
        std::printf("PASS (rows %llu+%llu)\n", (unsigned long long)(o0.geom.rows),
                    (unsigned long long)(o1.geom.rows));
    } else {
        std::printf("FAIL\n");
        ok = false;
    }

    // RowK
    o0 = shard_row_split(src.data(), sg, SplitSpec::RowK, 0, nr, buf0.data(), buf0.size(), stream);
    o1 = shard_row_split(src.data(), sg, SplitSpec::RowK, 1, nr, buf1.data(), buf1.size(), stream);
    cudaStreamSynchronize(stream);
    std::printf("RowK: ");
    if (verify_row_k(src.data(), sg, buf0.data(), o0.geom, buf1.data(), o1.geom)) {
        std::printf("PASS (cols %llu+%llu)\n", (unsigned long long)(o0.geom.columns),
                    (unsigned long long)(o1.geom.columns));
    } else {
        std::printf("FAIL\n");
        ok = false;
    }

    // Contiguous BF16 (word=2), ColumnN + RowK
    {
        const std::uint64_t crows = 32, ccols = 64, word = 2;
        const std::uint64_t total = crows * ccols * word;
        std::vector<unsigned char> csrc(total);
        fill_pattern(csrc.data(), total, 99);
        std::vector<unsigned char> cb0(total), cb1(total);
        ShardOutput c0 = shard_contiguous(csrc.data(), crows, ccols, word, SplitSpec::ColumnN, 0, nr,
                                          cb0.data(), cb0.size(), stream);
        ShardOutput c1 = shard_contiguous(csrc.data(), crows, ccols, word, SplitSpec::ColumnN, 1, nr,
                                          cb1.data(), cb1.size(), stream);
        cudaStreamSynchronize(stream);
        bool cok = std::memcmp(csrc.data(), cb0.data(), c0.geom.encoded_bytes) == 0 &&
                   std::memcmp(csrc.data() + c0.geom.encoded_bytes, cb1.data(),
                               c1.geom.encoded_bytes) == 0;
        std::printf("Contiguous ColumnN: %s\n", cok ? "PASS" : "FAIL");
        ok &= cok;

        c0 = shard_contiguous(csrc.data(), crows, ccols, word, SplitSpec::RowK, 0, nr, cb0.data(),
                              cb0.size(), stream);
        c1 = shard_contiguous(csrc.data(), crows, ccols, word, SplitSpec::RowK, 1, nr, cb1.data(),
                              cb1.size(), stream);
        cudaStreamSynchronize(stream);
        bool rok = true;
        for (std::uint64_t i = 0; i < crows; ++i) {
            const std::uint64_t half = (ccols / 2) * word;
            rok &= std::memcmp(csrc.data() + i * ccols * word, cb0.data() + i * half, half) == 0;
            rok &= std::memcmp(csrc.data() + i * ccols * word + half, cb1.data() + i * half, half) == 0;
        }
        std::printf("Contiguous RowK: %s\n", rok ? "PASS" : "FAIL");
        ok &= rok;
    }

    // Multi-range: fused [q|gate|k|v] projection, each rank takes a slice of every block.
    {
        // rows=64 as 4 blocks of 16: q[0,16) gate[16,32) k[32,48) v[48,64).
        auto make_ranges = [](int rank) { return std::vector<RowRange>{{rank * 8, 8},
                                                                        {16 + rank * 8, 8},
                                                                        {32 + rank * 8, 8},
                                                                        {48 + rank * 8, 8}}; };
        auto o_r = shard_row_ranges(src.data(), sg, make_ranges(0), buf0.data(), buf0.size(),
                                    stream);
        auto o_1 = shard_row_ranges(src.data(), sg, make_ranges(1), buf1.data(), buf1.size(),
                                    stream);
        cudaStreamSynchronize(stream);
        bool mok = o_r.geom.rows == 32 && o_1.geom.rows == 32 && o_r.geom.columns == cols;
        for (int rank = 0; rank < 2 && mok; ++rank) {
            const unsigned char* rbuf = rank == 0 ? buf0.data() : buf1.data();
            const ShardGeometry& rg = rank == 0 ? o_r.geom : o_1.geom;
            std::uint64_t dst_row0 = 0;
            for (const RowRange& rr : make_ranges(rank)) {
                const std::uint64_t groups = rr.count * sg.groups_per_row;
                mok &= check_plane(src.data(), rr.src_row0 * sg.groups_per_row * sg.low_bpg, rbuf,
                                   dst_row0 * rg.groups_per_row * rg.low_bpg,
                                   groups * sg.low_bpg, "mr low");
                mok &= check_plane(src.data(), sg.high_plane_offset +
                                                   rr.src_row0 * sg.groups_per_row * sg.high_bpg,
                                   rbuf, rg.high_plane_offset +
                                             dst_row0 * rg.groups_per_row * rg.high_bpg,
                                   groups * sg.high_bpg, "mr high");
                mok &= check_plane(src.data(), sg.scale_plane_offset +
                                                   rr.src_row0 * sg.groups_per_row * 2,
                                   rbuf, rg.scale_plane_offset + dst_row0 * rg.groups_per_row * 2,
                                   groups * 2, "mr scale");
                dst_row0 += rr.count;
            }
        }
        std::printf("MultiRange: %s\n", mok ? "PASS" : "FAIL");
        ok &= mok;
    }

    std::printf(ok ? "WEIGHT_SHARD TEST PASS\n" : "WEIGHT_SHARD TEST FAIL\n");
    return ok ? 0 : 1;
}
