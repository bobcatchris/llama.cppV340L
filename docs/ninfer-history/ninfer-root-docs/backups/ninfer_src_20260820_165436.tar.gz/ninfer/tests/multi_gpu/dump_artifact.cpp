// Dump every tensor object in the 27B artifact: name, shape, format, layout, bytes.
#include "artifact/reader.h"

#include <cstdio>
#include <string>

using namespace ninfer;
using namespace ninfer::artifact;

int main(int argc, char** argv) {
    const std::string path = argc > 1 ? argv[1] : "/home/intel/models/qwen3_6_27b.ninfer";
    Reader reader(path);
    const auto& objs = reader.objects();
    std::printf("total objects: %zu\n", objs.size());
    std::uint64_t total_bytes = 0;
    for (std::size_t i = 0; i < objs.size(); ++i) {
        const auto& o = objs[i];
        if (auto* t = std::get_if<TensorDescriptor>(&o)) {
            std::string shape;
            for (auto d : t->shape) shape += std::to_string(d) + "x";
            shape.pop_back();
            std::printf("[%zu] %-60s %-12s %-14s %s  %llu bytes\n", i, std::string(t->name).c_str(),
                        std::string(format_name(t->format)).c_str(),
                        std::string(layout_name(t->layout)).c_str(), shape.c_str(),
                        (unsigned long long)t->bytes);
            total_bytes += t->bytes;
        } else {
            const auto& r = std::get<ResourceDescriptor>(o);
            std::printf("[%zu] %-60s RESOURCE                            %llu bytes\n", i,
                        std::string(r.name).c_str(), (unsigned long long)r.bytes);
        }
    }
    std::printf("TOTAL tensor bytes: %llu (%.2f GB)\n", (unsigned long long)total_bytes,
                total_bytes / 1e9);
    return 0;
}
