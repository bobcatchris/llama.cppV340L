// Smoke test for the TP2 sharded loader (materialize_tp): materialize rank-0 text weights onto
// device 0, confirm the per-rank device capacity matches the planner, and D2H-verify one sharded
// weight of each split type against a CPU re-shard of the same full payload.
#include "artifact/reader.h"
#include "artifact/materializer.h"
#include "core/device.h"
#include "core/multi_gpu/weight_shard.h"
#include "targets/qwen3_6_27b/impl/load/tp_load.h"

#include <cstdio>
#include <cstring>
#include <map>
#include <string>
#include <vector>

using namespace ninfer;
using namespace ninfer::artifact;
using namespace ninfer::multi_gpu;
using namespace ninfer::targets::qwen3_6_27b::detail;

namespace {

ShardGeometry to_shard(const RowSplitGeometry& g) {
    ShardGeometry s;
    s.rows = g.rows; s.columns = g.columns; s.group_size = g.group_size;
    s.groups_per_row = g.groups_per_row; s.low_bpg = g.low_bytes_per_group;
    s.high_bpg = g.high_bytes_per_group; s.low_plane_bytes = g.low_plane_bytes;
    s.high_plane_offset = g.high_plane_offset; s.high_plane_bytes = g.high_plane_bytes;
    s.scale_plane_offset = g.scale_plane_offset; s.scale_plane_bytes = g.scale_plane_bytes;
    s.encoded_bytes = g.encoded_bytes;
    return s;
}

// Copy a device object's rank-local payload back to host, then verify it equals the CPU shard.
int verify_device_object(Reader& reader, MaterializedArtifact& mat, const std::string& name,
                         cudaStream_t stream) {
    const auto& objs = reader.objects();
    std::size_t idx = 0;
    for (std::size_t i = 0; i < objs.size(); ++i)
        if (auto* t = std::get_if<TensorDescriptor>(&objs[i]))
            if (t->name == name) { idx = i; break; }
    const auto* t = std::get_if<TensorDescriptor>(&objs[idx]);
    const PayloadSpan full = reader.payload(t->name);
    const RowSplitGeometry rg = row_split_geometry(t->format, t->shape);
    const ShardGeometry src = to_shard(rg);
    const TpRole role = classify_tp(name);
    const auto span = full.data.size();
    // Per-rank encoded size (device slot is this large, not the full span).
    const TpLocalShape loc = tp_local_shape(role, 0, 2,
                                            static_cast<std::int32_t>(t->shape[0]),
                                            static_cast<std::int32_t>(t->shape[1]));
    const std::uint64_t per_rank =
        (role == TpRole::Replicate) ? t->bytes
                                    : row_split_geometry(loc.rows, loc.columns, rg.group_size,
                                                         rg.low_bytes_per_group,
                                                         rg.high_bytes_per_group)
                                          .encoded_bytes;
    unsigned char* h_full = new unsigned char[span];
    std::memcpy(h_full, full.data.data(), span);
    unsigned char* h_cpu = new unsigned char[span];
    unsigned char* h_dev = new unsigned char[per_rank];

    // CPU reference shard (rank 0).
    if (role == TpRole::Replicate) {
        std::memcpy(h_cpu, h_full, span);  // full copy; per_rank == span
    } else if (role == TpRole::RowK) {
        shard_row_split(h_full, src, SplitSpec::RowK, 0, 2, h_cpu, span, 0);
    } else {
        std::vector<RowRange> r0;
        if (role == TpRole::MultiRangeGateUp) {
            r0 = {{0, 8704}, {17408, 8704}};  // gate[0:8704); up[17408:26112)
        } else if (role == TpRole::MultiRangeQK || role == TpRole::MultiRangeGV) {
            r0 = {{0, 3072}, {6144, 512}};
        } else if (role == TpRole::MultiRangeGQK) {
            r0 = {{0, 1024}, {2048, 1024}};
        } else {
            r0 = {{0, 3072}, {6144, 3072}};  // MultiRangeGZ
        }
        shard_row_ranges(h_full, src, r0, h_cpu, span, 0);
    }
    // Device payload (per-rank size).
    void* dev_ptr = mat.device_data(ObjectHandle{idx});
    if (const cudaError_t e = cudaMemcpy(h_dev, dev_ptr, per_rank, cudaMemcpyDeviceToHost); e != cudaSuccess) {
        std::printf("    D2H failed: %s\n", cudaGetErrorString(e));
        delete[] h_full; delete[] h_cpu; delete[] h_dev;
        return 1;
    }
    const bool ok = std::memcmp(h_cpu, h_dev, per_rank) == 0;
    std::printf("  [device] %-42s %s (full enc %llu, per-rank %llu)\n", name.c_str(),
                ok ? "PASS" : "FAIL", (unsigned long long)src.encoded_bytes,
                (unsigned long long)per_rank);
    delete[] h_full; delete[] h_cpu; delete[] h_dev;
    (void)stream;
    return ok ? 0 : 1;
}

}  // namespace

int main(int argc, char** argv) {
    const std::string path = argc > 1 ? argv[1] : "/home/intel/models/qwen3_6_27b.ninfer";
    Reader reader(path);
    DeviceContext ctx(0);
    cudaSetDevice(ctx.device);
    std::printf("materializing TP rank 0 / world 2 onto device %d\n", ctx.device);
    MaterializedArtifact mat = materialize_tp(reader, 0, 2, ctx);
    std::printf("per-rank device capacity: %.2f GB (expect ~9.1 GB)\n\n",
                mat.stats().device_capacity_bytes / 1e9);

    int fail = 0;
    fail += verify_device_object(reader, mat, "text/layers/0/mlp/gate_up", ctx.stream);
    fail += verify_device_object(reader, mat, "text/layers/0/mlp/down", ctx.stream);
    fail += verify_device_object(reader, mat, "text/layers/3/attention/query_key", ctx.stream);
    fail += verify_device_object(reader, mat, "text/layers/0/gdn/value_z", ctx.stream);
    std::printf("\nTP2 LOAD %s\n", fail == 0 ? "PASS" : "FAIL");
    return fail == 0 ? 0 : 1;
}
