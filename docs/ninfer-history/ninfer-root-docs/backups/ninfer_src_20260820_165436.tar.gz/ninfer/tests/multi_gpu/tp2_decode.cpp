// TP2 tensor-parallel decode for Qwen3.6-27B on two GPUs, with MTP (k drafts) rounds.
//
// Both ranks materialize the FULL 64-layer model with the full split (MLP + attention + GDN)
// sharded across the two ranks; every sharded output folds back via a per-layer NCCL allreduce.
// Rank 0 argmaxes and publishes tokens; a host barrier keeps the ranks in lockstep.
//
// MTP mode (--mtp K, default 3): after a single T=1 decode of the prompt anchor, every round is
//   1) MTP bridge step at the anchor position (replicated MTP head on each rank),
//   2) K-1 MTP autoregressive draft steps,
//   3) one main-model verify batch of width K+1 (all weights read once, per-column GDN/KV state
//      snapshots into a 5-slot ring),
//   4) greedy acceptance; the round commits (a+1) tokens and the accepted hidden seeds the next
//      bridge. The MTP head is replicated (identical drafts on both ranks); only rank 0's D2H
//      decisions are used.
//
// GDN state protocol: slots 0..4. The initial T=1 decode updates slot 0 in place. Round 0 verify
// starts from the pristine slot 4 (state before position 0); each round's verify starts from the
// committed slot s and snapshots columns onto s..s+3; acceptance moves the frontier to s+a.
//
// Usage: tp2_decode --artifact <path> [--prompt "..."] [--tokens N] [--ctx C] [--mtp K]
//                  [--devices a,b] [--workspace-gb N]

#include <cuda_bf16.h>

#include "artifact/binder.h"
#include "artifact/materializer.h"
#include "artifact/reader.h"
#include "core/arena.h"
#include "core/device.h"
#include "core/layout.h"
#include "core/multi_gpu/tp_group.h"
#include "core/paged_kv_cache.h"
#include "ninfer/ops/argmax.h"
#include "ninfer/ops/sampling.h"
#include "ninfer/ops/speculative_round.h"
#include "targets/qwen3_6/impl/frontend/tokenizer.h"
#include "targets/qwen3_6_27b/impl/load/bindings.h"
#include "targets/qwen3_6_27b/impl/load/tp_load.h"
#include "targets/qwen3_6_27b/impl/variant.h"

#include <ninfer/targets/qwen3_6_27b/package.h>
#include <ninfer/targets/qwen3_6/decoder_state.h>
#include <ninfer/targets/qwen3_6/round_state.h>

#define NINFER_QWEN36_VARIANT ::ninfer::targets::qwen3_6_27b::detail::Variant
#define NINFER_QWEN36_RUNTIME_NS qwen3_6_27b_runtime
#include "targets/qwen3_6/impl/runtime/instantiate.h"

#include <barrier>
#include <chrono>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <filesystem>
#include <iostream>
#include <memory>
#include <stdexcept>
#include <string>
#include <thread>
#include <vector>

namespace {

using namespace ninfer::targets::qwen3_6_27b::detail;
using ninfer::artifact::MaterializationPlan;
using ninfer::artifact::MaterializedArtifact;
using ninfer::artifact::Reader;
using ninfer::DeviceContext;
using ninfer::DeviceSpan;
using ninfer::DType;
using ninfer::LayoutBuilder;
using ninfer::LinearAttentionStatePoolSpec;
using ninfer::PagedKVAllocation;
using ninfer::ProposalHead;
using ninfer::ops::SamplingConfig;
using ninfer::SpeculativeBackend;
using ninfer::Tensor;
using ninfer::WorkspaceArena;
using ninfer::targets::qwen3_6_27b::Package;
using namespace ninfer::targets::qwen3_6;
namespace runtime = ninfer::targets::qwen3_6::detail::qwen3_6_27b_runtime;
using frontend_internal::Tokenizer;
using frontend_internal::TokenizerResources;
using Envelope = ninfer::ops::GqaExecutionEnvelope;

struct Options {
    std::filesystem::path artifact;
    std::string prompt   = "Hello, world!";
    int tokens           = 64;
    int ctx              = 4096;
    int mtp_k            = 3;  // drafts per round; 0 = plain TP2 decode
    bool noverify        = false;
    bool fakeaccept      = false;
    int dev0             = 0;
    int dev1             = 1;
    std::uint64_t workspace_bytes = 2ULL * 1024 * 1024 * 1024;
};

[[noreturn]] void usage() {
    std::cerr << "usage: tp2_decode --artifact <path> [--prompt S] [--tokens N] [--ctx C] "
                 "[--mtp K] [--devices a,b] [--workspace-gb N]\n";
    std::exit(2);
}

Options parse_options(int argc, char** argv) {
    Options o;
    for (int i = 1; i < argc; ++i) {
        const std::string a = argv[i];
        auto next = [&]() -> std::string {
            if (i + 1 >= argc) { usage(); }
            return argv[++i];
        };
        if (a == "--artifact") {
            o.artifact = next();
        } else if (a == "--prompt") {
            o.prompt = next();
        } else if (a == "--tokens") {
            o.tokens = std::atoi(next().c_str());
        } else if (a == "--ctx") {
            o.ctx = std::atoi(next().c_str());
        } else if (a == "--mtp") {
            o.mtp_k = std::atoi(next().c_str());
        } else if (a == "--noverify") {
            o.noverify = true;
        } else if (a == "--fakeaccept") {
            o.fakeaccept = true;
        } else if (a == "--devices") {
            const std::string d = next();
            const auto c        = d.find(',');
            if (c == std::string::npos) { usage(); }
            o.dev0 = std::atoi(d.substr(0, c).c_str());
            o.dev1 = std::atoi(d.substr(c + 1).c_str());
        } else if (a == "--workspace-gb") {
            o.workspace_bytes =
                static_cast<std::uint64_t>(std::stod(next())) * 1024ULL * 1024ULL * 1024ULL;
        } else {
            usage();
        }
    }
    if (o.artifact.empty() || o.tokens <= 0 || o.mtp_k < 0 || o.mtp_k > 3) { usage(); }
    return o;
}

struct RankState {
    explicit RankState(DeviceContext& c, std::size_t ws)
        : ctx(c), work(ws), persistent(1), staging(32ULL * 1024 * 1024) {}

    DeviceContext& ctx;
    std::string tokenizer_json;
    std::string tokenizer_config_json;
    std::string generation_config_json;
    std::unique_ptr<LoadedModelData> model;
    WorkspaceArena work;
    WorkspaceArena persistent;
    WorkspaceArena staging;
    std::unique_ptr<DecoderState> decoder;
    PagedKVAllocation kv_alloc;
    PagedKVCacheView kv_view;
    PagedKVAllocation mtp_kv_alloc;
    PagedKVCacheView mtp_view;
    std::unique_ptr<RoundState> round;
    Tensor prefill_dummy;
    std::unique_ptr<runtime::schedule::TextContext> text;

    // Plain decode tensors.
    Tensor ids, cpos, rpos, kvr, slt;   // I32 [1]
    Tensor hidden, logits;             // BF16 [5120,1] / [248320,1]
    Tensor token;                      // I32 [1]

    // MTP staging.
    Tensor ar_hidden;                  // BF16 [5120,1]  (bridge seed hidden)
    Tensor mh0, mh1, mh2;              // BF16 [5120,1]  (MTP ping-pong hidden)
    Tensor mtp_logits;                 // BF16 [248320,1]
    Tensor mtp_ph, mtp_pos, mtp_mh;    // MTP prefill: [5120,plen] hidden / [plen] pos / out
    Tensor drafts1;                    // I32 [3] (d0,d1,d2 contiguous)
    Tensor d0, d1, d2;                 // I32 [1] views of drafts1
    Tensor anchor, base_pos, ar_pos;   // I32 [1]
    Tensor extents, lengths;           // I32 [1] (extents = k, lengths = sequence length)
    Tensor licensed_counts, accepted;  // I32 [1]
    Tensor valid_v, kv_rows_v, state_slots;  // I32 [1] (4, 0, committed slot)
    Tensor verify_ids, verify_pos;     // I32 [4,1]
    Tensor verify_hidden;              // BF16 [5120,4,1]
    Tensor verify_logits;              // BF16 [248320,4,1]
    Tensor target_tokens;              // I32 [4,1]
    Tensor licensed;                   // I32 [4]
    SamplingConfig* sample_cfg         = nullptr;
    std::size_t accept_ws_bytes        = 0;
};

std::unique_ptr<RankState> make_rank(const Options& o, DeviceContext& ctx, const Reader& reader,
                                     const BindingPlan& bindings,
                                     ninfer::multi_gpu::TpGroup& group, int rank) {
    const bool mtp = o.mtp_k > 0;
    const int k    = mtp ? o.mtp_k : 0;
    cudaSetDevice(ctx.device);
    std::printf("[rank %d] materializing FULL sharded model (TP2, MTP k=%d) on device %d\n",
                rank, k, ctx.device);
    MaterializedArtifact mat = materialize_tp(reader, rank, 2, ctx);
    std::printf("[rank %d] materialized: %zu MB device (capacity)\n", rank,
                mat.stats().device_capacity_bytes / (1024 * 1024));

    auto state = std::make_unique<RankState>(ctx, o.workspace_bytes);
    state->model = std::make_unique<LoadedModelData>(
        bindings, std::move(mat), StageSpec{0, 64, true, true}, /*tp_world=*/2);
    state->tokenizer_json         = state->model->frontend.tokenizer_json;
    state->tokenizer_config_json  = state->model->frontend.tokenizer_config_json;
    state->generation_config_json = state->model->frontend.generation_config_json;

    const int cap        = o.ctx + o.mtp_k + 4;
    const std::uint32_t pages =
        1U + static_cast<std::uint32_t>(cap - 1) / static_cast<std::uint32_t>(ninfer::kPagedKVPageSize);
    auto decoder_spec = [&]() {
        return DecoderStateSpec{
            .full_attention_layers = 16,
            .mtp_layers            = mtp ? std::uint32_t(1) : std::uint32_t(0),
            .capacity              = static_cast<std::uint32_t>(cap),
            .kv_heads              = 2,  // TP: local kv-head block (4/2)
            .mtp_kv_heads          = 4,  // MTP pool replicated full-width
            .attention_head_dim    = 256,
            .kv_dtype              = DType::BF16,
            .kv_quant_group        = 0,
            .enable_mtp            = mtp,
            .kv_table_rows         = 1,
            .text_physical_page_groups = pages,
            .mtp_physical_page_groups  = mtp ? pages : 0,
            .linear_attention = LinearAttentionStatePoolSpec{
                // TP: local state per rank (value heads 48/2, conv channels 10240/2).
                // 5 slots: committed + verify column snapshots (1 + k).
                .layers         = 48,
                .conv_channels  = 5120,
                .conv_width     = 3,
                .value_heads    = 24,
                .value_head_dim = 128,
                .key_head_dim   = 128,
                .slot_count     = mtp ? 5 : 2,
                .conv_dtype     = DType::BF16,
            },
        };
    };
    {
        LayoutBuilder dry;
        const auto dry_dec = plan_decoder_state(dry, decoder_spec());
        const std::size_t dec_bytes = dry.finish(256);

        LayoutBuilder dry_round;
        auto dry_round_layout = begin_round_state_layout(
            dry_round, RoundStateSpec{.hidden = 5120, .output_rows = 248320, .batch_capacity = 1,
                                      .draft_window = static_cast<std::uint32_t>(mtp ? 3 : 0),
                                      .enable_mtp = mtp,
                                      .enable_dflash = false});
        complete_round_state_layout(dry_round, dry_round_layout);
        const std::size_t round_bytes = dry_round.finish(256);
        state->persistent = WorkspaceArena(dec_bytes + round_bytes + 1U * 1024 * 1024);
    }

    LayoutBuilder builder;
    const auto dec = plan_decoder_state(builder, decoder_spec());
    const DeviceSpan state_span = state->persistent.alloc_bytes(builder.finish(256), 256);
    state->decoder = std::make_unique<DecoderState>(state_span, dec);
    // Pristine GDN slots (verify round 0 reads the empty slot 4) and clean KV pages.
    CUDA_CHECK(cudaMemsetAsync(state_span.data, 0, state_span.bytes, ctx.stream));
    std::printf("[rank %d] decoder state: %zu MB, %u kv pages (cap %d)\n", rank,
                state_span.bytes / (1024 * 1024), pages, cap);

    auto& pool = state->decoder->text_kv.pool();
    state->kv_alloc = pool.reserve(pages);
    state->kv_alloc.bind_row(0, ctx.stream);
    state->kv_alloc.publish_mapping(ctx.stream);
    state->kv_view = state->decoder->text_kv.execution_view(state->kv_alloc);

    if (mtp) {
        auto& mtp_pool = state->decoder->mtp_cache()->pool();
        state->mtp_kv_alloc = mtp_pool.reserve(pages);
        state->mtp_kv_alloc.bind_row(0, ctx.stream);
        state->mtp_kv_alloc.publish_mapping(ctx.stream);
        state->mtp_view = state->decoder->mtp_cache()->execution_view(state->mtp_kv_alloc);
    }

    LayoutBuilder round_builder;
    auto round_layout = begin_round_state_layout(
        round_builder,
        RoundStateSpec{.hidden = 5120, .output_rows = 248320, .batch_capacity = 1,
                       .draft_window = static_cast<std::uint32_t>(mtp ? 3 : 0), .enable_mtp = mtp,
                       .enable_dflash = false});
    complete_round_state_layout(round_builder, round_layout);
    const DeviceSpan round_span = state->persistent.alloc_bytes(round_builder.finish(256), 256);
    state->round = std::make_unique<RoundState>(round_span, round_layout);
    // We bypass the program, so seed the IO scalars it would otherwise set (KV table rows are 0
    // because each rank bound a single table row on its allocation).
    {
        const int zero = 0;
        CUDA_CHECK(cudaMemcpy(state->round->text_kv_table_row.data, &zero, sizeof(int),
                              cudaMemcpyHostToDevice));
        CUDA_CHECK(cudaMemcpy(state->round->backend_kv_table_row.data, &zero, sizeof(int),
                              cudaMemcpyHostToDevice));
    }

    state->prefill_dummy = state->persistent.alloc(DType::BF16, {5120, 1});

    const PagedKVCache* mtp_kv_ptr = mtp ? state->decoder->mtp_cache() : nullptr;
    state->text = std::make_unique<runtime::schedule::TextContext>(
        ctx, state->model->runtime, state->work, state->kv_view,
        state->decoder->linear_attention, *state->round, state->prefill_dummy,
        static_cast<std::uint32_t>(o.ctx), 0, state->mtp_view, &state->decoder->text_kv,
        mtp_kv_ptr, 0, 64);
    state->text->set_tp(&group, rank, 2);
    std::printf("[rank %d] TextContext ready (full 64 layers, TP rank %d, MTP %s)\n", rank, rank,
                mtp ? "on" : "off");

    // Staging tensors (per-rank, device-local).
    auto a_i32 = [&]() { return state->staging.alloc(DType::I32, {1, 1}); };
    auto a_bf  = [&](int rows) { return state->staging.alloc(DType::BF16, {rows, 1}); };
    state->ids       = a_i32();
    state->cpos      = a_i32();
    state->rpos      = a_i32();
    state->kvr       = a_i32();
    state->slt       = a_i32();
    state->hidden    = a_bf(5120);
    state->logits    = a_bf(248320);
    state->token     = a_i32();

    state->ar_hidden  = state->persistent.alloc(DType::BF16, {5120, 1});
    state->mh0        = state->persistent.alloc(DType::BF16, {5120, 1});
    state->mh1        = state->persistent.alloc(DType::BF16, {5120, 1});
    state->mh2        = state->persistent.alloc(DType::BF16, {5120, 1});
    state->mtp_logits = a_bf(248320);
    state->drafts1    = state->staging.alloc(DType::I32, {3, 1});
    state->d0         = state->drafts1.slice(0, 0, 1);
    state->d1         = state->drafts1.slice(0, 1, 1);
    state->d2         = state->drafts1.slice(0, 2, 1);
    state->anchor        = a_i32();
    state->base_pos      = a_i32();
    state->ar_pos        = a_i32();
    state->extents       = a_i32();
    state->lengths       = a_i32();
    state->licensed_counts = a_i32();
    state->accepted      = a_i32();
    state->valid_v       = a_i32();
    state->kv_rows_v     = a_i32();
    state->state_slots   = a_i32();
    state->verify_ids    = state->staging.alloc(DType::I32, {4, 1});
    state->verify_pos    = state->staging.alloc(DType::I32, {4, 1});
    state->verify_hidden = state->staging.alloc(DType::BF16, {5120, 4, 1});
    state->verify_logits = state->staging.alloc(DType::BF16, {248320, 4, 1});
    state->target_tokens = state->staging.alloc(DType::I32, {4, 1});
    state->licensed      = state->staging.alloc(DType::I32, {4, 1});

    CUDA_CHECK(cudaMalloc(reinterpret_cast<void**>(&state->sample_cfg), sizeof(SamplingConfig)));
    {
        SamplingConfig greedy;  // defaults: temperature 0 (greedy)
        CUDA_CHECK(cudaMemcpy(state->sample_cfg, &greedy, sizeof(SamplingConfig),
                              cudaMemcpyHostToDevice));
    }
    state->accept_ws_bytes =
        k > 0 ? ninfer::ops::speculative_accept_greedy_drafts_workspace_capacity_bytes(248320, k, k,
                                                                                        1, 1)
              : 0;

    int ext    = k;
    int valid  = 4;
    int zero   = 0;
    int one    = 1;
    CUDA_CHECK(cudaMemcpyAsync(state->extents.data, &ext, sizeof(int), cudaMemcpyHostToDevice,
                               ctx.stream));
    CUDA_CHECK(cudaMemcpyAsync(state->valid_v.data, &valid, sizeof(int), cudaMemcpyHostToDevice,
                               ctx.stream));
    CUDA_CHECK(cudaMemcpyAsync(state->kv_rows_v.data, &zero, sizeof(int), cudaMemcpyHostToDevice,
                               ctx.stream));
    CUDA_CHECK(cudaMemcpyAsync(state->kvr.data, &zero, sizeof(int), cudaMemcpyHostToDevice,
                               ctx.stream));
    CUDA_CHECK(cudaMemcpyAsync(state->slt.data, &zero, sizeof(int), cudaMemcpyHostToDevice,
                               ctx.stream));
    CUDA_CHECK(cudaMemcpyAsync(state->lengths.data, &one, sizeof(int), cudaMemcpyHostToDevice,
                               ctx.stream));
    return state;
}

struct RoundCursor {
    std::atomic<int> anchor{0};  // committed anchor token t_F
    std::atomic<int> F{0};       // frontier position
    std::atomic<int> slot{0};    // committed GDN slot (always rebased to 0)
};

}  // namespace

int main(int argc, char** argv) {
    const Options o = parse_options(argc, argv);
    const bool mtp = o.mtp_k > 0;
    const int k    = mtp ? o.mtp_k : 0;
    const auto t_start = std::chrono::steady_clock::now();

    ninfer::multi_gpu::TpGroup group(
        ninfer::multi_gpu::TpGroupOptions{.devices = {o.dev0, o.dev1}});
    DeviceContext& ctx0 = group.ctx(0);
    DeviceContext& ctx1 = group.ctx(1);

    Reader reader(o.artifact);
    auto binder = std::make_unique<ninfer::artifact::Binder>(reader);
    const WeightsProfile profile = Package::resolve_weights(reader.identity());
    if (profile != WeightsProfile::Qwen36GroupwiseInt) {
        std::cerr << "tp2_decode: expected the Qwen3.6-27B groupwise-int artifact\n";
        return 1;
    }
    const auto load_plan = bind_artifact(
        *binder, profile,
        StartupFeatures{.vision = false,
                        .speculative = mtp ? SpeculativeBackend::Mtp : SpeculativeBackend::None,
                        .proposal_head = ProposalHead::Full});
    const BindingPlan& bindings = load_plan.bindings;
    std::printf("artifact: %zu objects, %zu MB device total\n",
                static_cast<std::size_t>(load_plan.materialization.object_count),
                load_plan.materialization.device_capacity_bytes / (1024 * 1024));

    auto rank0 = make_rank(o, ctx0, reader, bindings, group, 0);
    auto rank1 = make_rank(o, ctx1, reader, bindings, group, 1);

    Tokenizer tokenizer(TokenizerResources{
        .tokenizer_json         = rank0->tokenizer_json,
        .tokenizer_config_json  = rank0->tokenizer_config_json,
        .generation_config_json = rank0->generation_config_json,
    });
    const std::vector<int> prompt_ids = tokenizer.encode(o.prompt);
    if (prompt_ids.empty()) {
        std::cerr << "tp2_decode: empty prompt encoding\n";
        return 1;
    }
    std::printf("prompt: %d tokens (%s)\n", static_cast<int>(prompt_ids.size()), o.prompt.c_str());
    std::printf("mode: %s (k=%d), tokens=%d\n", mtp ? "MTP" : "plain TP2 decode", k, o.tokens);

    std::barrier sync_bar(2);
    std::vector<int> all_ids(prompt_ids.begin(), prompt_ids.end());
    RoundCursor cursor;
    cursor.anchor.store(prompt_ids.back());
    cursor.F.store(static_cast<int>(prompt_ids.size()) - 1);
    cursor.slot.store(0);

    auto worker = [&](RankState& st, cudaStream_t s) {
        const int rank = (st.ctx.device == ctx0.device) ? 0 : 1;
        cudaSetDevice(st.ctx.device);
        const auto write = [&](Tensor& t, int value) {
            CUDA_CHECK(cudaMemcpyAsync(t.data, &value, sizeof(int), cudaMemcpyHostToDevice, s));
        };

        // ---------------- prompt prefill: decode every prompt token (T=1 path) ----------------
        // The driver has no batched prefill kernel, so we run the working T=1 decode once per
        // prompt token to build real KV + GDN context. After the loop, st.hidden is the hidden
        // state at position plen-1 (the seed for the MTP bridge) and the anchor sits at plen-1.
        const int plen = static_cast<int>(prompt_ids.size());
        // MTP head prefill buffers (persistent; plen is fixed for the run).
        st.mtp_ph  = st.persistent.alloc(DType::BF16, {5120, plen});
        st.mtp_pos = st.persistent.alloc(DType::I32, {plen});
        st.mtp_mh  = st.persistent.alloc(DType::BF16, {5120, plen});
        Tensor mtp_ids = st.persistent.alloc(DType::I32, {plen});
        std::vector<int> mtp_pos_h(plen);
        for (int i = 0; i < plen; ++i) { mtp_pos_h[i] = i; }
        CUDA_CHECK(cudaMemcpyAsync(mtp_ids.data, prompt_ids.data(), plen * sizeof(int),
                                   cudaMemcpyHostToDevice, s));
        CUDA_CHECK(cudaMemcpyAsync(st.mtp_pos.data, mtp_pos_h.data(), plen * sizeof(int),
                                   cudaMemcpyHostToDevice, s));
        for (int i = 0; i < plen; ++i) {
            write(st.ids, prompt_ids[i]);
            write(st.cpos, i);
            write(st.rpos, i);
            st.text->ordinary_decode_batch(st.ids, st.cpos, st.rpos, st.kvr, st.slt,
                                           Envelope{static_cast<std::uint32_t>(i + 1),
                                                    static_cast<std::uint32_t>(i + 1)},
                                           st.hidden, st.logits);
            // Save the target hidden at position i for the MTP head prefill.
            CUDA_CHECK(cudaMemcpyAsync(
                reinterpret_cast<char*>(st.mtp_ph.data) + static_cast<std::size_t>(i) * 5120 * 2,
                st.hidden.data, 5120 * 2, cudaMemcpyDeviceToDevice, s));
        }
        // MTP head prefill: populate the MTP KV cache with the prompt context so the bridge/AR
        // attend over the full history (not just the seed hidden). Without this the MTP KV cache
        // is empty and round 1+ drafts collapse.
        if (mtp) {
            st.text->mtp_forward_batch(mtp_ids, st.mtp_ph, st.mtp_pos,
                                       Envelope{static_cast<std::uint32_t>(plen),
                                                static_cast<std::uint32_t>(plen)},
                                       st.mtp_mh, -1, nullptr, nullptr);
        }
        CUDA_CHECK(cudaMemcpyAsync(st.ar_hidden.data, st.hidden.data, 5120 * 2,
                                   cudaMemcpyDeviceToDevice, s));
        if (rank == 0) { st.ctx.synchronize(); }

        int generated = 0;
        if (!mtp) {
            // ---------------- plain TP2 decode (reference path) ----------------
            for (int step = 0; step < o.tokens && generated < o.tokens; ++step) {
                const int tok  = cursor.anchor.load();
                const int cpos = cursor.F.load();
                const auto t0 = std::chrono::steady_clock::now();
                write(st.ids, tok);
                write(st.cpos, cpos);
                write(st.rpos, cpos);
                st.text->ordinary_decode_batch(st.ids, st.cpos, st.rpos, st.kvr, st.slt,
                                               Envelope{static_cast<std::uint32_t>(cpos + 1),
                                                        static_cast<std::uint32_t>(cpos + 1)},
                                               st.hidden, st.logits);
                if (rank == 0) {
                    const auto t1 = std::chrono::steady_clock::now();
                    ninfer::ops::argmax(st.logits, st.token, 248320, s);
                    st.ctx.synchronize();
                    int next = 0;
                    CUDA_CHECK(cudaMemcpy(&next, st.token.data, sizeof(int), cudaMemcpyDeviceToHost));
                    cursor.anchor.store(next);
                    cursor.F.store(cpos + 1);
                    all_ids.push_back(next);
                    generated++;
                    if (step < 3 || step % 8 == 0) {
                        std::printf("  [step %d] %.1f ms token=%d (%s)\n", step,
                                    std::chrono::duration<double, std::milli>(t1 - t0).count(),
                                    next, tokenizer.decode_token_bytes(next, false).c_str());
                    }
                }
                sync_bar.arrive_and_wait();
            }
        } else {
            // ---------------- MTP rounds ----------------
            for (int round = 0; generated < o.tokens; ++round) {
                const int F    = cursor.F.load();
                const int slot = cursor.slot.load();
                const auto t0  = std::chrono::steady_clock::now();

                write(st.anchor, cursor.anchor.load());
                write(st.base_pos, F);
                write(st.state_slots, slot);

                if (round < 3) {
                    int dev_anchor = -1;
                    CUDA_CHECK(cudaMemcpyAsync(&dev_anchor, st.anchor.data, sizeof(int),
                                               cudaMemcpyDeviceToHost, s));
                    std::vector<__nv_bfloat16> arh(4), mh(4);
                    CUDA_CHECK(cudaMemcpyAsync(arh.data(), st.ar_hidden.data, 8,
                                               cudaMemcpyDeviceToHost, s));
                    CUDA_CHECK(cudaStreamSynchronize(s));
                    // Run the bridge first so mh0 reflects this round, then read mh0.
                    st.text->mtp_forward_batch(st.anchor, st.ar_hidden, st.base_pos,
                                               Envelope{static_cast<std::uint32_t>(F + 1),
                                                        static_cast<std::uint32_t>(F + 1)},
                                               st.mh0, -1, nullptr, nullptr);
                    CUDA_CHECK(cudaMemcpyAsync(mh.data(), st.mh0.data, 8, cudaMemcpyDeviceToHost, s));
                    CUDA_CHECK(cudaStreamSynchronize(s));
                    std::fprintf(stderr,
                                 "  [r%d] host_anchor=%d F=%d dev_anchor=%d arh=[%.3f %.3f %.3f %.3f]"
                                 " mh=[%.3f %.3f %.3f %.3f]\n", round, cursor.anchor.load(), F,
                                 dev_anchor, __bfloat162float(arh[0]), __bfloat162float(arh[1]),
                                 __bfloat162float(arh[2]), __bfloat162float(arh[3]),
                                 __bfloat162float(mh[0]), __bfloat162float(mh[1]),
                                 __bfloat162float(mh[2]), __bfloat162float(mh[3]));
                    // re-run bridge with logits to produce d0 for the real pipeline
                    st.text->mtp_forward_batch(st.anchor, st.ar_hidden, st.base_pos,
                                               Envelope{static_cast<std::uint32_t>(F + 1),
                                                        static_cast<std::uint32_t>(F + 1)},
                                               st.mh0, 0, &st.mtp_logits, &st.d0);
                } else {
                    st.text->mtp_forward_batch(st.anchor, st.ar_hidden, st.base_pos,
                                               Envelope{static_cast<std::uint32_t>(F + 1),
                                                        static_cast<std::uint32_t>(F + 1)},
                                               st.mh0, 0, &st.mtp_logits, &st.d0);
                }
                // 1) MTP bridge at the anchor position; hidden seed = accepted verify hidden.
                st.text->mtp_forward_batch(st.anchor, st.ar_hidden, st.base_pos,
                                           Envelope{static_cast<std::uint32_t>(F + 1),
                                                    static_cast<std::uint32_t>(F + 1)},
                                           st.mh0, 0, &st.mtp_logits, &st.d0);
                // 2) AR draft chain (k-1 steps).
                const Tensor* mh_prev = &st.mh0;
                Tensor& d_prev        = st.d0;
                Tensor& d_cur         = st.d1;
                for (int i = 1; i < k; ++i) {
                    if (round < 3) { std::fprintf(stderr, "  [r%d] ar%d\n", round, i); }
                    write(st.ar_pos, F + i);
                    st.text->mtp_forward_ar_step(d_prev, *mh_prev, st.ar_pos,
                                                 Envelope{static_cast<std::uint32_t>(F + i + 1),
                                                          static_cast<std::uint32_t>(F + i + 1)},
                                                 i == 2 ? st.mh2 : st.mh1, st.mtp_logits, d_cur);
                    if (i == 1) { d_prev = st.d1; d_cur = st.d2; mh_prev = &st.mh1; }
                    else        { mh_prev = &st.mh2; }
                }
                // 3) Verify batch: [anchor, d0..d_{k-1}] at positions F..F+k, width k+1.
                if (o.noverify) {
                    int d2v = 0;
                    st.ctx.synchronize();
                    CUDA_CHECK(cudaMemcpy(&d2v, st.d2.data, sizeof(int), cudaMemcpyDeviceToHost));
                    cursor.anchor.store(d2v);
                    cursor.F.store(F + k + 1);
                    generated += k + 1;
                    if (rank == 0) {
                        for (int j = 0; j < k + 1; ++j) { all_ids.push_back(-1); }
                        if (round < 3) { std::printf("  [round %d] noverify d2=%d\n", round, d2v); }
                    }
                    sync_bar.arrive_and_wait();
                    continue;
                }
                Tensor drafts2(st.drafts1.data, DType::I32, {k, 1});
                ninfer::ops::speculative_prepare_verify_inputs(
                    st.anchor, drafts2, st.base_pos, st.extents, st.verify_ids, st.verify_pos,
                    s);
                if (round < 3) { std::fprintf(stderr, "  [r%d] verify\n", round); }
                st.text->target_verify_batch(
                    st.verify_ids, st.verify_pos, st.verify_pos, st.valid_v, st.kv_rows_v,
                    st.state_slots,
                    Envelope{static_cast<std::uint32_t>(F + k + 1),
                             static_cast<std::uint32_t>(F + k + 1)},
                    st.verify_hidden, st.verify_logits, st.target_tokens);
                // 4) Greedy acceptance + hidden selection for the next bridge.
                if (round < 3) { std::fprintf(stderr, "  [r%d] accept\n", round); }
                if (o.fakeaccept) {
                    // Verify ran (pool+state writes); fake full acceptance, skip accept op.
                    int d2v = 0;
                    st.ctx.synchronize();
                    CUDA_CHECK(cudaMemcpy(&d2v, st.d2.data, sizeof(int), cudaMemcpyDeviceToHost));
                    cursor.anchor.store(d2v);
                    cursor.F.store(F + k + 1);
                    st.decoder->linear_attention.copy_slot(k, 0, s);
                    generated += k + 1;
                    if (rank == 0 && round < 3) {
                        std::printf("  [round %d] fakeaccept d2=%d\n", round, d2v);
                    }
                    sync_bar.arrive_and_wait();
                    continue;
                }
                ninfer::ops::speculative_accept_greedy_drafts(
                    st.target_tokens, st.verify_logits, drafts2, st.extents, st.lengths, st.anchor,
                    st.licensed, st.licensed_counts, st.accepted, 248320, st.sample_cfg, st.work, s);
                ninfer::ops::speculative_select_accepted_hidden(st.verify_hidden, st.accepted,
                                                               st.ar_hidden, s);

                const auto t1 = std::chrono::steady_clock::now();
                // Both ranks read the acceptance result: verify is deterministic and replicated,
                // so a/lic are identical on both ranks. This keeps the round loop lockstep.
                int a = 0, lic[4] = {0, 0, 0, 0};
                st.ctx.synchronize();
                CUDA_CHECK(cudaMemcpy(&a, st.accepted.data, sizeof(int), cudaMemcpyDeviceToHost));
                CUDA_CHECK(cudaMemcpy(lic, st.licensed.data, sizeof(int) * 4,
                                      cudaMemcpyDeviceToHost));
                if (rank == 0 && round < 4) {
                    int dv[3] = {0, 0, 0}, tv[4] = {0, 0, 0, 0};
                    CUDA_CHECK(cudaMemcpy(dv, st.drafts1.data, sizeof(int) * 3,
                                          cudaMemcpyDeviceToHost));
                    CUDA_CHECK(cudaMemcpy(tv, st.target_tokens.data, sizeof(int) * 4,
                                          cudaMemcpyDeviceToHost));
                    std::printf("  [r%d] drafts=[%d %d %d] target=[%d %d %d %d]\n", round,
                                dv[0], dv[1], dv[2], tv[0], tv[1], tv[2], tv[3]);
                }
                generated += a + 1;
                cursor.anchor.store(lic[a]);
                cursor.F.store(F + a + 1);
                st.decoder->linear_attention.copy_slot(a, 0, s);  // rebase committed snapshot -> slot 0
                if (rank == 0) {
                    for (int j = 0; j <= a; ++j) { all_ids.push_back(lic[j]); }
                    if (round < 3 || round % 8 == 0) {
                        std::printf("  [round %d] %.1f ms a=%d tokens=%d %d %d %d\n", round,
                                    std::chrono::duration<double, std::milli>(t1 - t0).count(), a,
                                    lic[0], lic[1], lic[2], lic[3]);
                    }
                }
                sync_bar.arrive_and_wait();
            }
        }
    };

    const auto t_decode = std::chrono::steady_clock::now();
    std::thread th1([&] { worker(*rank1, ctx1.stream); });
    worker(*rank0, ctx0.stream);  // run rank 0 on the main thread
    th1.join();
    group.synchronize_all();

    const auto t_end = std::chrono::steady_clock::now();
    const double dt  = std::chrono::duration<double>(t_end - t_decode).count();
    const int generated = static_cast<int>(all_ids.size()) - static_cast<int>(prompt_ids.size());
    std::printf("decoded %d tokens in %.2f s (%.2f t/s)\n", generated, dt,
                generated > 0 ? generated / dt : 0.0);

    std::string output;
    for (int id : all_ids) { output += tokenizer.decode_token_bytes(id, false); }
    std::printf("---- output ----\n%s\n---- end ----\n", output.c_str());

    const double t_total =
        std::chrono::duration<double>(std::chrono::steady_clock::now() - t_start).count();
    std::printf("total wall time: %.2f s\n", t_total);
    return 0;
}
