// PP2 pipeline-parallel decode for Qwen3.6-27B on two GPUs.
//
//   rank 0: embedding + layers [0, 32)            -> hidden
//          P2P (NCCL) hidden -> rank 1
//   rank 1: layers [32, 64) + final_norm + lm_head -> logits -> argmax -> token
//
// Each rank materializes only its own subset of the artifact (subset_materialization_plan),
// owns its own DeviceContext/arena, per-stage paged KV cache (8 full + 24 GDN layers) and
// linear-attention state pool (24 GDN layers).
//
// Usage: pp2_decode --artifact <path> --prompt "..." --tokens N [--ctx C] [--devices a,b]

#include "artifact/binder.h"
#include "artifact/materializer.h"
#include "artifact/plan_split.h"
#include "artifact/reader.h"
#include "core/arena.h"
#include "core/device.h"
#include "core/layout.h"
#include "core/multi_gpu/tp_group.h"
#include "core/paged_kv_cache.h"
#include "ninfer/ops/argmax.h"
#include "targets/qwen3_6/impl/frontend/tokenizer.h"
#include "targets/qwen3_6_27b/impl/load/bindings.h"
#include "targets/qwen3_6_27b/impl/variant.h"

#include <ninfer/targets/qwen3_6_27b/package.h>
#include <ninfer/targets/qwen3_6/decoder_state.h>
#include <ninfer/targets/qwen3_6/round_state.h>

#define NINFER_QWEN36_VARIANT ::ninfer::targets::qwen3_6_27b::detail::Variant
#define NINFER_QWEN36_RUNTIME_NS qwen3_6_27b_runtime
#include "targets/qwen3_6/impl/runtime/instantiate.h"

#include <chrono>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <filesystem>
#include <iostream>
#include <memory>
#include <stdexcept>
#include <string>
#include <vector>

namespace {

using namespace ninfer::targets::qwen3_6_27b::detail;
using ninfer::artifact::MaterializationPlan;
using ninfer::artifact::MaterializedArtifact;
using ninfer::artifact::ObjectHandle;
using ninfer::artifact::Reader;
using ninfer::artifact::subset_materialization_plan;
using ninfer::DeviceContext;
using ninfer::DeviceSpan;
using ninfer::DType;
using ninfer::LayoutBuilder;
using ninfer::LinearAttentionStatePoolSpec;
using ninfer::PagedKVAllocation;
using ninfer::ProposalHead;
using ninfer::SpeculativeBackend;
using ninfer::Tensor;
using ninfer::WorkspaceArena;
using ninfer::targets::qwen3_6_27b::Package;
using namespace ninfer::targets::qwen3_6;
namespace runtime = ninfer::targets::qwen3_6::detail::qwen3_6_27b_runtime;
using frontend_internal::DecodeOptions;
using frontend_internal::Tokenizer;
using frontend_internal::TokenizerResources;

struct Options {
    std::filesystem::path artifact;
    std::string prompt   = "Hello, world!";
    int tokens           = 32;
    int ctx              = 4096;
    int dev0             = 0;
    int dev1             = 1;
    std::uint64_t workspace_bytes = 2ULL * 1024 * 1024 * 1024;
};

[[noreturn]] void usage() {
    std::cerr << "usage: pp2_decode --artifact <path> [--prompt S] [--tokens N] [--ctx C] "
                 "[--devices a,b] [--workspace-gb N]\n";
    std::exit(2);
}

Options parse_options(int argc, char** argv) {
    Options o;
    for (int i = 1; i < argc; ++i) {
        const std::string a = argv[i];
        auto next = [&]() -> std::string {
            if (i + 1 >= argc) { usage(); }
            return argv[++i];
        };
        if (a == "--artifact") {
            o.artifact = next();
        } else if (a == "--prompt") {
            o.prompt = next();
        } else if (a == "--tokens") {
            o.tokens = std::atoi(next().c_str());
        } else if (a == "--ctx") {
            o.ctx = std::atoi(next().c_str());
        } else if (a == "--devices") {
            const std::string d = next();
            const auto c        = d.find(',');
            if (c == std::string::npos) { usage(); }
            o.dev0 = std::atoi(d.substr(0, c).c_str());
            o.dev1 = std::atoi(d.substr(c + 1).c_str());
        } else if (a == "--workspace-gb") {
            o.workspace_bytes =
                static_cast<std::uint64_t>(std::stod(next())) * 1024ULL * 1024ULL * 1024ULL;
        } else {
            usage();
        }
    }
    if (o.artifact.empty() || o.tokens <= 0) { usage(); }
    return o;
}

// Collect every device object handle referenced by one text layer plan.
std::vector<ObjectHandle> layer_handles(const TextLayerPlan& layer) {
    std::vector<ObjectHandle> out;
    out.push_back(layer.input_norm);
    out.push_back(layer.post_attention_norm);
    if (layer.is_full_attention) {
        const auto& attn = layer.attention;
        if (const auto* split = std::get_if<SplitAttentionProjectionPlan>(&attn.projection)) {
            out.push_back(split->query_key.object);
            out.push_back(split->gate_value.object);
        } else {
            const auto* fused = std::get_if<FusedAttentionProjectionPlan>(&attn.projection);
            out.push_back(fused->query_key_gate_value.object);
        }
        out.push_back(attn.query_norm);
        out.push_back(attn.key_norm);
        out.push_back(attn.output.object);
    } else {
        const auto& gdn = layer.gdn;
        out.push_back(gdn.a_log);
        out.push_back(gdn.dt_bias);
        out.push_back(gdn.convolution);
        if (const auto* split = std::get_if<SplitGdnControlProjectionPlan>(&gdn.control_projection)) {
            out.push_back(split->a_projection.object);
            out.push_back(split->b_projection.object);
        } else {
            const auto* fused =
                std::get_if<FusedGdnControlProjectionPlan>(&gdn.control_projection);
            out.push_back(fused->a_b_projection.object);
        }
        if (const auto* split =
                std::get_if<SplitGdnInputProjectionPlan>(&gdn.input_projection)) {
            out.push_back(split->query_key.object);
            out.push_back(split->value_z.object);
        } else {
            const auto* fused = std::get_if<FusedGdnInputProjectionPlan>(&gdn.input_projection);
            out.push_back(fused->query_key_value_z.object);
        }
        out.push_back(gdn.norm);
        out.push_back(gdn.output.object);
    }
    out.push_back(layer.mlp.gate_up.object);
    out.push_back(layer.mlp.down.object);
    return out;
}

std::vector<ObjectHandle> stage_handles(const BindingPlan& plan, std::uint32_t first,
                                        std::uint32_t last, bool embedding, bool lm_head) {
    std::vector<ObjectHandle> out;
    if (embedding) { out.push_back(plan.token_embedding.object); }
    for (std::uint32_t layer = first; layer < last; ++layer) {
        for (const ObjectHandle& handle : layer_handles(plan.text_layers[layer])) {
            out.push_back(handle);
        }
    }
    if (lm_head) {
        out.push_back(plan.final_norm);
        out.push_back(plan.output_head.object);
    }
    return out;
}

struct StageState {
    // `work` is the TextContext scratch arena (reset every round); `staging` holds live
    // per-step tensors (hidden/logits/positions) that must survive those resets.
    explicit StageState(DeviceContext& c, std::size_t ws)
        : ctx(c), work(ws), persistent(1), staging(16ULL * 1024 * 1024) {}

    DeviceContext& ctx;
    std::string tokenizer_json;
    std::string tokenizer_config_json;
    std::string generation_config_json;
    std::unique_ptr<LoadedModelData> model;
    WorkspaceArena work;       // round-trip scratch (TextContext resets this every round)
    WorkspaceArena persistent; // decoder state + round state + prefill dummy (never reset)
    WorkspaceArena staging;    // live per-step tensors
    std::unique_ptr<DecoderState> decoder;
    PagedKVAllocation kv_alloc;
    PagedKVCacheView kv_view;
    std::unique_ptr<RoundState> round;
    Tensor prefill_dummy;
    std::unique_ptr<runtime::schedule::TextContext> text;
};

std::unique_ptr<StageState>
make_stage(const Options& o, DeviceContext& ctx, const Reader& reader, std::uint32_t first_layer,
           std::uint32_t last_layer, bool embedding, bool lm_head, const BindingPlan& bindings,
           const MaterializationPlan& full_mat) {
    const int rank = first_layer == 0 ? 0 : 1;
    // TpGroup builds contexts on worker threads; the main thread's current device is still 0.
    // cudaMalloc (arena construction, materialize H2D staging) is current-device scoped.
    cudaSetDevice(ctx.device);
    std::printf("[rank %d] building stage: layers [%d, %d) + %s + %s\n", rank,
                static_cast<int>(first_layer), static_cast<int>(last_layer),
                embedding ? "embedding" : "no-embedding", lm_head ? "lm_head" : "no-lm_head");
    const auto keep = stage_handles(bindings, first_layer, last_layer, embedding, lm_head);
    const auto subset = subset_materialization_plan(full_mat, keep, full_mat.object_count);
    std::printf("[rank %d] stage plan: %zu tensors kept, %zu MB device (of %zu MB full)\n", rank,
                subset.plan.device_objects.size(), subset.plan.device_capacity_bytes / (1024 * 1024),
                full_mat.device_capacity_bytes / (1024 * 1024));

    auto state = std::make_unique<StageState>(ctx, o.workspace_bytes);

    MaterializedArtifact mat = ninfer::artifact::materialize(reader, subset.plan, ctx);
    std::printf("[rank %d] materialized %zu tensors (%zu MB h2d)\n", rank,
                mat.stats().tensor_count, mat.stats().h2d_bytes / (1024 * 1024));

    const StageSpec stage{first_layer, last_layer, embedding, lm_head};
    state->model = std::make_unique<LoadedModelData>(bindings, std::move(mat), stage);
    // initialize() already extracted the frontend resources (take_* moves them out).
    state->tokenizer_json         = state->model->frontend.tokenizer_json;
    state->tokenizer_config_json  = state->model->frontend.tokenizer_config_json;
    state->generation_config_json = state->model->frontend.generation_config_json;

    // Per-stage decoder state: 8 full-attention + 24 GDN layers (symmetric 32/32 split).
    // Persistent state lives in its own arena: TextContext resets the work arena every round,
    // which would otherwise overwrite the KV pool / GDN state / round tensors.
    const std::uint32_t pages =
        1U + (static_cast<std::uint32_t>(o.ctx) - 1U) /
            static_cast<std::uint32_t>(ninfer::kPagedKVPageSize);
    {
        LayoutBuilder dry;
        const auto dry_dec = plan_decoder_state(
            dry, DecoderStateSpec{
                .full_attention_layers = 8,
                .mtp_layers            = 0,
                .capacity              = static_cast<std::uint32_t>(o.ctx),
                .kv_heads              = 4,
                .attention_head_dim    = 256,
                .kv_dtype              = DType::BF16,
                .kv_quant_group        = 0,
                .enable_mtp            = false,
                .kv_table_rows         = 1,
                .text_physical_page_groups = pages,
                .linear_attention = LinearAttentionStatePoolSpec{
                    .layers         = 24,
                    .conv_channels  = 10240,
                    .conv_width     = 3,
                    .value_heads    = 48,
                    .value_head_dim = 128,
                    .key_head_dim   = 128,
                    .slot_count     = 2,
                    .conv_dtype     = DType::BF16,
                },
            });
        const std::size_t dec_bytes = dry.finish(256);

        LayoutBuilder dry_round;
        auto dry_round_layout = begin_round_state_layout(
            dry_round, RoundStateSpec{
                .hidden          = 5120,
                .output_rows     = 248320,
                .batch_capacity  = 1,
                .draft_window    = 0,
                .enable_mtp      = false,
                .enable_dflash   = false,
            });
        complete_round_state_layout(dry_round, dry_round_layout);
        const std::size_t round_bytes = dry_round.finish(256);

        state->persistent = WorkspaceArena(dec_bytes + round_bytes + 1U * 1024 * 1024);
    }

    LayoutBuilder builder;
    const auto dec = plan_decoder_state(
        builder, DecoderStateSpec{
            .full_attention_layers = 8,
            .mtp_layers            = 0,
            .capacity              = static_cast<std::uint32_t>(o.ctx),
            .kv_heads              = 4,
            .attention_head_dim    = 256,
            .kv_dtype              = DType::BF16,
            .kv_quant_group        = 0,
            .enable_mtp            = false,
            .kv_table_rows         = 1,
            .text_physical_page_groups = pages,
            .linear_attention = LinearAttentionStatePoolSpec{
                .layers         = 24,
                .conv_channels  = 10240,
                .conv_width     = 3,
                .value_heads    = 48,
                .value_head_dim = 128,
                .key_head_dim   = 128,
                .slot_count     = 2,
                .conv_dtype     = DType::BF16,
            },
        });
    const DeviceSpan state_span = state->persistent.alloc_bytes(builder.finish(256), 256);
    state->decoder              = std::make_unique<DecoderState>(state_span, dec);
    std::printf("[rank %d] decoder state: %zu MB, %u kv pages\n", rank,
                state_span.bytes / (1024 * 1024), pages);

    auto& pool = state->decoder->text_kv.pool();
    state->kv_alloc = pool.reserve(pages);
    state->kv_alloc.bind_row(0, ctx.stream);
    state->kv_alloc.publish_mapping(ctx.stream);
    state->kv_view = state->decoder->text_kv.execution_view(state->kv_alloc);

    LayoutBuilder round_builder;
    auto round_layout = begin_round_state_layout(
        round_builder, RoundStateSpec{
            .hidden          = 5120,
            .output_rows     = 248320,
            .batch_capacity  = 1,
            .draft_window    = 0,
            .enable_mtp      = false,
            .enable_dflash   = false,
        });
    complete_round_state_layout(round_builder, round_layout);
    const DeviceSpan round_span =
        state->persistent.alloc_bytes(round_builder.finish(256), 256);
    state->round = std::make_unique<RoundState>(round_span, round_layout);

    state->prefill_dummy = state->persistent.alloc(DType::BF16, {5120, 1});

    state->text = std::make_unique<runtime::schedule::TextContext>(
        ctx, state->model->runtime, state->work, state->kv_view,
        state->decoder->linear_attention, *state->round, state->prefill_dummy,
        static_cast<std::uint32_t>(o.ctx), 0, PagedKVCacheView(), &state->decoder->text_kv,
        nullptr,
        static_cast<std::int32_t>(first_layer), static_cast<std::int32_t>(last_layer));
    std::printf("[rank %d] TextContext staged: layers [%d, %d)\n", rank,
                static_cast<int>(first_layer), static_cast<int>(last_layer));
    return state;
}

} // namespace

int main(int argc, char** argv) {
    const Options o = parse_options(argc, argv);
    const auto t_start = std::chrono::steady_clock::now();

    // ---------------------------------------------------------------- rank setup
    ninfer::multi_gpu::TpGroup group(
        ninfer::multi_gpu::TpGroupOptions{.devices = {o.dev0, o.dev1}});
    DeviceContext& ctx0 = group.ctx(0);
    DeviceContext& ctx1 = group.ctx(1);

    // Bind the full artifact once (host metadata); each rank materializes its own subset.
    Reader reader(o.artifact);
    auto binder = std::make_unique<ninfer::artifact::Binder>(reader);
    const WeightsProfile profile = Package::resolve_weights(reader.identity());
    if (profile != WeightsProfile::Qwen36GroupwiseInt) {
        std::cerr << "pp2_decode: expected the Qwen3.6-27B groupwise-int artifact\n";
        return 1;
    }
    const auto load_plan = bind_artifact(
        *binder, profile,
        StartupFeatures{
            .vision        = false,
            .speculative   = SpeculativeBackend::None,
            .proposal_head = ProposalHead::Full});
    const BindingPlan& bindings = load_plan.bindings;
    const MaterializationPlan& full_mat = load_plan.materialization;
    std::printf("artifact: %zu objects, %zu MB device total\n",
                static_cast<std::size_t>(full_mat.object_count),
                full_mat.device_capacity_bytes / (1024 * 1024));

    auto stage0 = make_stage(o, ctx0, reader, 0, 32, true, false, bindings, full_mat);
    auto stage1 = make_stage(o, ctx1, reader, 32, 64, false, true, bindings, full_mat);

    // ---------------------------------------------------------------- tokenization
    Tokenizer tokenizer(TokenizerResources{
        .tokenizer_json         = stage0->tokenizer_json,
        .tokenizer_config_json  = stage0->tokenizer_config_json,
        .generation_config_json = stage0->generation_config_json,
    });
    const std::vector<int> prompt_ids = tokenizer.encode(o.prompt);
    if (prompt_ids.empty()) {
        std::cerr << "pp2_decode: empty prompt encoding\n";
        return 1;
    }
    std::printf("prompt: %d tokens (%s)\n", static_cast<int>(prompt_ids.size()), o.prompt.c_str());

    // ---------------------------------------------------------------- staging tensors
    const int hidden_dim = 5120;
    auto alloc_i32  = [](WorkspaceArena& w) { return w.alloc(DType::I32, {1, 1}); };
    auto alloc_bf16 = [&](WorkspaceArena& w, int rows) { return w.alloc(DType::BF16, {rows, 1}); };
    Tensor ids0   = alloc_i32(stage0->staging);
    Tensor cpos0  = alloc_i32(stage0->staging);
    Tensor rpos0  = alloc_i32(stage0->staging);
    Tensor cpos1  = alloc_i32(stage1->staging);
    Tensor rpos1  = alloc_i32(stage1->staging);
    Tensor kvr0   = alloc_i32(stage0->staging);
    Tensor kvr1   = alloc_i32(stage1->staging);
    Tensor slt0   = alloc_i32(stage0->staging);
    Tensor slt1   = alloc_i32(stage1->staging);
    Tensor hidden0   = alloc_bf16(stage0->staging, hidden_dim);
    Tensor hidden1   = alloc_bf16(stage1->staging, hidden_dim);
    Tensor norm1     = alloc_bf16(stage1->staging, hidden_dim);
    Tensor logits1   = alloc_bf16(stage1->staging, 248320);
    Tensor token1    = alloc_i32(stage1->staging);
    const int zero   = 0;
    cudaStream_t s0  = ctx0.stream;
    cudaStream_t s1  = ctx1.stream;
    auto fill = [](Tensor& t, int value, cudaStream_t s) {
        CUDA_CHECK(cudaMemcpyAsync(t.data, &value, sizeof(int), cudaMemcpyHostToDevice, s));
    };
    fill(kvr0, 0, s0);
    fill(kvr1, 0, s1);
    fill(slt0, 0, s0);
    fill(slt1, 0, s1);
    CUDA_CHECK(cudaDeviceSynchronize());

    // ---------------------------------------------------------------- decode loop
    std::vector<int> all_ids(prompt_ids.begin(), prompt_ids.end());
    int position = 0;
    std::printf("generating %d tokens from position %d (empty cache)\n", o.tokens, position);
    const auto t_decode = std::chrono::steady_clock::now();

    auto now_ms = [] { return std::chrono::duration<double, std::milli>(
                                   std::chrono::steady_clock::now().time_since_epoch()).count(); };
    for (int step = 0; step < o.tokens; ++step) {
        const double t_start = now_ms();
        const int tok = all_ids.back();
        const int pos = position;
        position += 1;
        if (pos >= o.ctx) { break; }

        auto write_i32 = [](Tensor& t, int value, cudaStream_t s) {
            CUDA_CHECK(cudaMemcpyAsync(t.data, &value, sizeof(int), cudaMemcpyHostToDevice, s));
        };
        write_i32(ids0, tok, s0);
        write_i32(cpos0, pos, s0);
        write_i32(rpos0, pos, s0);
        write_i32(cpos1, pos, s1);
        write_i32(rpos1, pos, s1);
        const double t_h2d = now_ms();

        const ninfer::ops::GqaExecutionEnvelope envelope{static_cast<std::uint32_t>(pos + 1),
                                                         static_cast<std::uint32_t>(pos + 1)};

        // Bring-up flow: strictly ordered (correctness first, overlap later via events).
        // NCCL P2P runs on NCCL worker streams, so the head decode must be finished before the
        // send reads hidden0, and the recv must be drained before the tail decode reads hidden1.
        cudaEvent_t ev_a, ev_b, ev_c, ev_d;
        // Events are per-device context resources: create each pair on its own device.
        cudaSetDevice(ctx0.device);
        cudaEventCreate(&ev_a);
        cudaEventCreate(&ev_b);
        cudaSetDevice(ctx1.device);
        cudaEventCreate(&ev_c);
        cudaEventCreate(&ev_d);
        cudaEventRecord(ev_a, s0);
        stage0->text->stage_head_decode(ids0, cpos0, rpos0, kvr0, slt0, envelope, hidden0);
        cudaEventRecord(ev_b, s0);
        const double t_enq0 = now_ms();
        ctx0.synchronize();
        const double t_sync0 = now_ms();
        const std::size_t hidden_bytes = static_cast<std::size_t>(hidden_dim) * 1U * 2U;
        group.send(hidden0.data, hidden_bytes, 0, 1);
        group.recv(hidden1.data, hidden_bytes, 1, 0);
        group.synchronize_all();
        const double t_nccl = now_ms();
        cudaEventRecord(ev_c, s1);
        stage1->text->stage_tail_decode(hidden1, cpos1, rpos1, kvr1, slt1, envelope, norm1,
                                        logits1);
        ninfer::ops::argmax(logits1, token1, 248320, s1);
        cudaEventRecord(ev_d, s1);
        const double t_enq1 = now_ms();
        ctx1.synchronize();
        const double t_sync1 = now_ms();
        float t01 = 0, t23 = 0;
        cudaEventElapsedTime(&t01, ev_a, ev_b);
        cudaEventElapsedTime(&t23, ev_c, ev_d);
        if (step == 0 || step % 8 == 0) {
            std::printf(
                "    [timing] gpu0=%.1f gpu1=%.1f | h2d=%.1f enq0=%.1f sync0=%.1f nccl=%.1f enq1=%.1f sync1=%.1f | total=%.1f\n",
                t01, t23, t_h2d - t_start, t_enq0 - t_h2d, t_sync0 - t_enq0, t_nccl - t_sync0,
                t_enq1 - t_nccl, t_sync1 - t_enq1, t_sync1 - t_start);
        }
        cudaSetDevice(ctx0.device);
        cudaEventDestroy(ev_a);
        cudaEventDestroy(ev_b);
        cudaSetDevice(ctx1.device);
        cudaEventDestroy(ev_c);
        cudaEventDestroy(ev_d);

        int next = 0;
        CUDA_CHECK(cudaMemcpy(&next, token1.data, sizeof(int), cudaMemcpyDeviceToHost));
        all_ids.push_back(next);

        if (step < 3 || step % 8 == 0) {
            std::printf("  [step %d] token=%d (%s)\n", step, next,
                        tokenizer.decode_token_bytes(next, false).c_str());
        }
    }
    group.synchronize_all();
    const auto t_end = std::chrono::steady_clock::now();
    const double dt = std::chrono::duration<double>(t_end - t_decode).count();
    const int generated = static_cast<int>(all_ids.size()) - static_cast<int>(prompt_ids.size());
    std::printf("decoded %d tokens in %.2f s (%.2f t/s)\n", generated, dt,
                generated > 0 ? generated / dt : 0.0);

    std::string output;
    for (int id : all_ids) { output += tokenizer.decode_token_bytes(id, false); }
    std::printf("---- output ----\n%s\n---- end ----\n", output.c_str());

    const double t_total =
        std::chrono::duration<double>(std::chrono::steady_clock::now() - t_start).count();
    std::printf("total wall time: %.2f s\n", t_total);
    return 0;
}
