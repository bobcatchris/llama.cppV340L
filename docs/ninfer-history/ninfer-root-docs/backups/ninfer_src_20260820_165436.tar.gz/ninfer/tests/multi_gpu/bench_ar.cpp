// Microbench: NCCL allreduce latency at TP2 working-set sizes on 2x 5060 Ti (PHB, no P2P).
#include "core/multi_gpu/tp_group.h"
#include "core/device.h"

#include <chrono>
#include <cstdio>
#include <vector>

using namespace ninfer;
using namespace ninfer::multi_gpu;

int main() {
    TpGroupOptions o;
    o.devices = {0, 1};
    TpGroup group(std::move(o));

    const std::size_t cap   = 16ULL * 1024 * 1024;
    DeviceArena& a0 = group.make_arena(0, cap);
    DeviceArena& a1 = group.make_arena(1, cap);

    // Sizes: per-layer allreduce payload candidates (bf16 elements).
    std::vector<std::size_t> elems = {2560, 5120, 8704, 17408, 34816, 124160 / 2, 124160};
    for (std::size_t n : elems) {
        void* p0 = a0.alloc_bytes(n * 2, 256).data;
        void* p1 = a1.alloc_bytes(n * 2, 256).data;
        std::vector<void*> ptrs{p0, p1};
        // Warmup
        for (int i = 0; i < 50; ++i) {
            group.allreduce_bf16(ptrs, n);
        }
        group.synchronize_all();
        auto t0 = std::chrono::steady_clock::now();
        const int iters = 1000;
        for (int i = 0; i < iters; ++i) {
            group.allreduce_bf16(ptrs, n);
        }
        auto t1 = std::chrono::steady_clock::now();
        double us = std::chrono::duration<double, std::micro>(t1 - t0).count() / iters;
        std::printf("AR %8zu elems (%6.2f KB): %8.1f us/call  ->  128 ARs/step = %6.1f ms\n", n,
                    n * 2.0 / 1024.0, us, us * 128.0 / 1e6);
    }
    std::printf("done\n");
    return 0;
}
