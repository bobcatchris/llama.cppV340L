// Stub media decoder used when NInfer is built without FFMPEG (NINFER_HAVE_FFMPEG=OFF).
// Provides the same symbols as media/decode/decode.cpp so the engine links unchanged.
// The text-only inference path never calls these; only the unused vision path would,
// and it fails fast with a clear error.
#include "media/decode/decode.h"

namespace ninfer::media::decode {

Image decode_image(std::span<const std::uint8_t>, const Policy&) {
  throw Error(ErrorKind::BudgetExceeded,
              "media decode unavailable: NInfer built without FFMPEG (NINFER_HAVE_FFMPEG=OFF)");
}

Video decode_video(std::span<const std::uint8_t>, const Policy&, double, int, int) {
  throw Error(ErrorKind::BudgetExceeded,
              "media decode unavailable: NInfer built without FFMPEG (NINFER_HAVE_FFMPEG=OFF)");
}

}  // namespace ninfer::media::decode
