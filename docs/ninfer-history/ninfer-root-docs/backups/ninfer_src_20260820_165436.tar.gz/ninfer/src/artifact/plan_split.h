#pragma once

// Multi-GPU pipeline split: restrict one full materialization plan to a rank-local subset of
// device objects. The full artifact object_count is preserved (ObjectHandle space stays valid
// for every rank), and device offsets are recomputed with the exact sequential align_up walk that
// Binder::finish() and DeviceArena::alloc_bytes() use, so materialize() accepts the subset plan
// and places every kept object at a matching offset in the rank-local arena.
//
// Objects not kept by a rank remain in the handle space but are not materialized on that rank;
// MaterializedArtifact::device_data() throws for them, which stage-aware binding relies on.

#include "artifact/binder.h"

#include <algorithm>
#include <cstdint>
#include <limits>
#include <stdexcept>
#include <string>
#include <vector>

namespace ninfer::artifact {

namespace plan_split_detail {

std::uint64_t checked_add(std::uint64_t a, std::uint64_t b, const char* label) {
    if (b > std::numeric_limits<std::uint64_t>::max() - a) { throw std::invalid_argument(label); }
    return a + b;
}

std::uint64_t align_up(std::uint64_t value, std::uint64_t alignment) {
    if (alignment == 0 || (alignment & (alignment - 1)) != 0) {
        throw std::invalid_argument("materialization alignment must be a positive power of two");
    }
    return checked_add(value, alignment - 1, "materialization offset overflows u64") /
           alignment * alignment;
}

} // namespace plan_split_detail

struct StageMaterializationPlan {
    MaterializationPlan plan;
    std::vector<std::size_t> kept_object_indexes;
};

// keep: the handles this rank materializes on device (order does not matter; the output preserves
// the full plan's order). total_object_count: the full artifact object count (handle space).
[[nodiscard]] inline StageMaterializationPlan
subset_materialization_plan(const MaterializationPlan& full,
                            const std::vector<ObjectHandle>& keep,
                            std::size_t total_object_count) {
    if (keep.empty()) { throw std::invalid_argument("stage plan must keep at least one object"); }
    if (total_object_count == 0 || total_object_count != full.object_count) {
        throw std::invalid_argument("stage plan total object count does not match the full plan");
    }

    std::vector<bool> keep_mask(total_object_count, false);
    std::vector<std::size_t> kept;
    kept.reserve(keep.size());
    for (const ObjectHandle& handle : keep) {
        if (handle.index >= total_object_count) {
            throw std::out_of_range("stage plan keep handle is outside the artifact handle space");
        }
        if (keep_mask[handle.index]) { continue; }
        keep_mask[handle.index] = true;
        kept.push_back(handle.index);
    }

    StageMaterializationPlan out;
    out.plan.object_count          = total_object_count;
    out.plan.host_objects          = full.host_objects;
    out.plan.device_capacity_bytes = 0;
    out.kept_object_indexes        = kept;

    // Preserve the full plan's device order; recompute offsets with the same sequential walk.
    for (const DeviceMaterialization& placement : full.device_objects) {
        if (!keep_mask[placement.object.index]) { continue; }
        const std::uint64_t offset = plan_split_detail::align_up(
            out.plan.device_capacity_bytes, placement.alignment);
        out.plan.device_objects.push_back(
            DeviceMaterialization{placement.object, offset, placement.bytes, placement.alignment});
        out.plan.device_capacity_bytes =
            plan_split_detail::checked_add(offset, placement.bytes,
                                           "stage materialization capacity overflows u64");
    }
    if (out.plan.device_objects.empty()) {
        throw std::invalid_argument("stage plan keeps no device tensors");
    }
    return out;
}

} // namespace ninfer::artifact
