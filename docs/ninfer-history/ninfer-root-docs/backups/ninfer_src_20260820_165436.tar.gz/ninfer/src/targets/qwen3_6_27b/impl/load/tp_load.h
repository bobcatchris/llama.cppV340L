#pragma once

#include <cstdint>
#include <string>

#include "artifact/materializer.h"
#include "artifact/reader.h"
#include "core/device.h"

namespace ninfer::targets::qwen3_6_27b::detail {

// Tensor-parallel split role for a 27B text object (world-size agnostic).
//   MultiRangeGateUp : gate_up block split (gate_local; up_local) so local SwiGLU stays aligned
//   MultiRangeQKV    : fused attention projection [q;k;gate;v] per-head-block row slices
//   MultiRange*      : per-head-block row slices          (attn query_key/gate_value, gdn query_key/value_z)
//   RowK             : input-column (group) split         (mlp/down, attention output) -> allreduce
//   Replicate        : full copy on every rank            (gdn, embedding, norms, output_head)
enum class TpRole { MultiRangeGateUp, MultiRangeQKV, MultiRangeQK, MultiRangeGV, MultiRangeGQK,
                    MultiRangeGZ, GdnConv, RowK, Replicate };

[[nodiscard]] TpRole classify_tp(const std::string& name);

// Local (rows, columns) of one rank's slice of a full (full_rows, full_cols) weight. Replicated
// roles return the full shape. The rank's device payload is laid out as a valid row-split weight of
// exactly this local shape, so it is read back by materialized_weight with the same local dims.
struct TpLocalShape {
    std::int32_t rows     = 0;
    std::int32_t columns  = 0;
    [[nodiscard]] bool sharded() const noexcept { return rows > 0; }
};
[[nodiscard]] TpLocalShape tp_local_shape(TpRole role, int rank, int world, std::int32_t full_rows,
                                          std::int32_t full_columns);

// Materialize the text tensors (MTP-off, vision excluded) for one TP rank: sharded groupwise
// projections are H2D-sharded into the rank's DeviceArena, replicated tensors are H2D-copied whole.
// Returns a MaterializedArtifact whose device_data(handle) points at each object's rank-local payload
// (null for non-text objects, which are never dereferenced in text decode).
[[nodiscard]] artifact::MaterializedArtifact
materialize_tp(const artifact::Reader& reader, int rank, int world,
               const DeviceContext& device, artifact::LoadProgress* progress = nullptr);

}  // namespace ninfer::targets::qwen3_6_27b::detail
