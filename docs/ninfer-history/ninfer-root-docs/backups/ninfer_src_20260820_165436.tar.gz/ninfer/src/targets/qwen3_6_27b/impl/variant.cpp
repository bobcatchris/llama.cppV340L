#include "targets/qwen3_6_27b/impl/variant.h"
#define NINFER_QWEN36_VARIANT    ::ninfer::targets::qwen3_6_27b::detail::Variant
#define NINFER_QWEN36_RUNTIME_NS qwen3_6_27b_runtime
#include "targets/qwen3_6/impl/runtime/instantiate.h"

// The runtime is instantiated exactly once per process: in this TU for the engine,
// or in a consumer TU that includes instantiate.h directly (e.g. the PP2 test driver).
