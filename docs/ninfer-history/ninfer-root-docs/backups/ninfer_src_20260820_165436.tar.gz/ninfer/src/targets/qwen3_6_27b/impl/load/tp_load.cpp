#include "load/tp_load.h"

#include "artifact/materializer.h"
#include "core/arena.h"
#include "core/device.h"
#include "core/multi_gpu/weight_shard.h"

#include <cuda_runtime.h>

#include <cstring>
#include <stdexcept>
#include <string>
#include <vector>

namespace ninfer::targets::qwen3_6_27b::detail {

using namespace ninfer::artifact;
using multi_gpu::RowRange;
using multi_gpu::ShardGeometry;
using multi_gpu::ShardOutput;
using multi_gpu::SplitSpec;

namespace {

constexpr std::uint64_t kAlign = 256;

std::uint64_t align_up(std::uint64_t v) { return (v + kAlign - 1) & ~(kAlign - 1); }

ShardGeometry to_shard(const RowSplitGeometry& g) {
    ShardGeometry s;
    s.rows               = g.rows;
    s.columns            = g.columns;
    s.group_size         = g.group_size;
    s.groups_per_row     = g.groups_per_row;
    s.low_bpg            = g.low_bytes_per_group;
    s.high_bpg           = g.high_bytes_per_group;
    s.low_plane_bytes    = g.low_plane_bytes;
    s.high_plane_offset  = g.high_plane_offset;
    s.high_plane_bytes   = g.high_plane_bytes;
    s.scale_plane_offset = g.scale_plane_offset;
    s.scale_plane_bytes  = g.scale_plane_bytes;
    s.encoded_bytes      = g.encoded_bytes;
    return s;
}

std::vector<RowRange> multi_ranges(TpRole role, int rank, int world) {
    const auto r = static_cast<std::uint64_t>(rank);
    switch (role) {
        // gate_up is block-layout [gate(I); up(I)] with I = 17408. Local SwiGLU needs this rank's
        // gate rows and the matching up rows, so we take gate[r*h,(r+1)*h) and up[I+r*h, I+(r+1)*h)
        // (h = I/world). Concatenated in order -> local [gate_local; up_local] block layout.
        case TpRole::MultiRangeGateUp: {
            const std::uint64_t I   = 17408;
            const std::uint64_t h   = I / static_cast<std::uint64_t>(world);
            return {{r * h, h}, {I + r * h, h}};
        }
        // Fused attention projection [q(6144); k(1024); gate(6144); v(1024)] (14336 rows). Each rank
        // takes its local q/gate head block and its local kv head block, concatenated in the same
        // [q;k;gate;v] order -> local [q_local; k_local; gate_local; v_local].
        case TpRole::MultiRangeQKV: {
            const std::uint64_t qh  = 6144 / static_cast<std::uint64_t>(world);
            const std::uint64_t kvh = 1024 / static_cast<std::uint64_t>(world);
            return {{r * qh, qh},          // q_local   [0, 6144)
                    {6144 + r * kvh, kvh}, // k_local   [6144, 7168)
                    {7168 + r * qh, qh},   // gate_local [7168, 13312)
                    {13312 + r * kvh, kvh}};  // v_local [13312, 14336)
        }
        case TpRole::MultiRangeQK:  return {{r * 3072, 3072}, {6144 + r * 512, 512}};
        case TpRole::MultiRangeGV:  return {{r * 3072, 3072}, {6144 + r * 512, 512}};
        case TpRole::MultiRangeGQK: return {{r * 1024, 1024}, {2048 + r * 1024, 1024}};
        case TpRole::MultiRangeGZ:  return {{r * 3072, 3072}, {6144 + r * 3072, 3072}};
        default:                    return {};
    }
}

bool is_multi(TpRole role) {
    return role == TpRole::MultiRangeGateUp || role == TpRole::MultiRangeQKV ||
           role == TpRole::MultiRangeQK || role == TpRole::MultiRangeGV ||
           role == TpRole::MultiRangeGQK || role == TpRole::MultiRangeGZ;
}

struct ObjPlan {
    std::size_t index   = 0;
    TpRole role         = TpRole::Replicate;
    bool sharded        = false;
    std::uint64_t bytes = 0;
};

}  // namespace

// Phase 2a (MLP-only split): only the feed-forward block is partitioned across ranks; attention
// and GDN projections stay full/replicated on every rank (identical inputs -> identical outputs).
// Phase 2b will extend this to the full per-head split (MultiRange* + RowK for attn/gdn).
TpRole classify_tp(const std::string& name) {
    std::string rel = name;
    const auto a = name.find("text/layers/");
    if (a != std::string::npos) {
        const auto b = name.find('/', a + 12);
        rel = (b == std::string::npos) ? std::string{} : name.substr(b + 1);
    }
    if (rel == "mlp/gate_up") return TpRole::MultiRangeGateUp;  // [34816,5120] -> [17408,5120]/rank (gate;up)
    if (rel == "mlp/down")    return TpRole::RowK;               // [5120,17408] -> [5120,8704]/rank + AR
    // Fused artifact variant (single [q;k;gate;v] tensor).
    if (rel == "attention/query_key_gate_value") return TpRole::MultiRangeQKV;  // [14336,5120] -> [7168,5120]/rank
    // Split artifact variant (this 27b artifact): separate [q;k] and [gate;v] tensors.
    if (rel == "attention/query_key")  return TpRole::MultiRangeQK;  // [7168,5120] -> [3584,5120]/rank (q;k)
    if (rel == "attention/gate_value") return TpRole::MultiRangeGV;  // [7168,5120] -> [3584,5120]/rank (gate;v)
    if (rel == "attention/output") return TpRole::RowK;          // [5120,6144] -> [5120,3072]/rank + AR
    // GDN (48 layers): value head h -> key head h/3, so rank r's value-head block owns a
    // contiguous key-head block. query_key [q(2048); k(2048)] -> local [q_local; k_local] (2048);
    // value_z [v(6144); z(6144)] -> local [v_local; z_local] (6144); output RowK + AR.
    if (rel == "gdn/query_key")    return TpRole::MultiRangeGQK;  // [4096,5120]  -> [2048,5120]/rank
    if (rel == "gdn/value_z")      return TpRole::MultiRangeGZ;   // [12288,5120] -> [6144,5120]/rank
    if (rel == "gdn/convolution")  return TpRole::GdnConv;        // BF16 [4,10240] -> [4,5120]/rank
    if (rel == "gdn/output")       return TpRole::RowK;           // [5120,6144] -> [5120,3072]/rank + AR
    (void)name;
    return TpRole::Replicate;  // gdn control (a_log, dt_bias, a/b), norms, embedding, output_head
}

TpLocalShape tp_local_shape(TpRole role, int rank, int world, std::int32_t full_rows,
                            std::int32_t full_columns) {
    const auto w = static_cast<std::int32_t>(world);
    (void)rank;
    switch (role) {
        case TpRole::MultiRangeGateUp:   return {full_rows / w, full_columns};
        case TpRole::RowK:               return {full_rows, full_columns / w};
        case TpRole::MultiRangeQKV:      return {full_rows / w, full_columns};
        case TpRole::MultiRangeQK:       return {3584, full_columns};
        case TpRole::MultiRangeGV:       return {3584, full_columns};
        case TpRole::MultiRangeGQK:      return {2048, full_columns};
        case TpRole::MultiRangeGZ:       return {6144, full_columns};
        case TpRole::GdnConv:            return {full_rows, full_columns / w};  // BF16 [4, 5120]
        case TpRole::Replicate:          return {full_rows, full_columns};
    }
    return {0, 0};
}

MaterializedArtifact materialize_tp(const Reader& reader, int rank, int world,
                                    const DeviceContext& device, LoadProgress* progress) {
    if (world < 1 || rank < 0 || rank >= world) {
        throw std::invalid_argument("materialize_tp: bad rank/world");
    }
    const auto& objs = reader.objects();
    const std::size_t object_count = objs.size();

    // Pass 1: classify, decide role, compute per-rank bytes, sum capacity.
    std::vector<ObjPlan> plans(object_count);
    std::uint64_t capacity = 0;
    int n_text = 0;
    for (std::size_t i = 0; i < object_count; ++i) {
        const auto* t = std::get_if<TensorDescriptor>(&objs[i]);
        if (t == nullptr) continue;
        // vision excluded; mtp objects load replicated (the MTP head runs identically on every
        // rank; deterministic drafts, only rank 0's host decisions are used).
        if (t->name.rfind("text/", 0) != 0 && t->name.rfind("mtp/", 0) != 0) { continue; }
        if (t->name.rfind("text/draft_head", 0) == 0) continue;
        const TpRole role = classify_tp(t->name);
        const bool sharded = role != TpRole::Replicate;
        std::uint64_t bytes;
        if (sharded && role == TpRole::GdnConv) {
            // Raw BF16 conv weight [taps, channels]: local channels = channels/world, tap-major.
            bytes = (t->shape[1] / static_cast<std::uint64_t>(world)) * t->shape[0] * 2u;
        } else if (sharded) {
            const RowSplitGeometry full = row_split_geometry(t->format, t->shape);
            const TpLocalShape loc = tp_local_shape(role, rank, world,
                                                    static_cast<std::int32_t>(t->shape[0]),
                                                    static_cast<std::int32_t>(t->shape[1]));
            bytes = multi_gpu::row_split_geometry(
                        static_cast<std::uint64_t>(loc.rows),
                        static_cast<std::uint64_t>(loc.columns), full.group_size,
                        full.low_bytes_per_group, full.high_bytes_per_group)
                        .encoded_bytes;
        } else {
            bytes = t->bytes;
        }
        plans[i].index   = i;
        plans[i].role    = role;
        plans[i].sharded = sharded;
        plans[i].bytes   = bytes;
        capacity        += align_up(bytes);
        ++n_text;
    }
    if (progress != nullptr && progress->callback) progress->callback("tp-weights", 0, capacity);

    auto arena = std::make_unique<DeviceArena>(static_cast<std::size_t>(capacity));
    const cudaStream_t stream = (device.load_stream != nullptr) ? device.load_stream
                                                                : device.stream;

    // Pass 2: allocate each rank-local slot and H2D (shard or copy).
    std::vector<void*> device_ptrs(object_count, nullptr);
    std::uint64_t done = 0;
    for (const ObjPlan& p : plans) {
        if (p.index >= object_count || device_ptrs[p.index] != nullptr) continue;
        const auto* t = std::get_if<TensorDescriptor>(&objs[p.index]);
        if (t == nullptr) continue;
        const PayloadSpan payload = reader.payload(t->name);
        const DeviceSpan slot = arena->alloc_bytes(static_cast<std::size_t>(p.bytes), kAlign);
        if (p.sharded && p.role == TpRole::GdnConv) {
            // Payload is tap-major: tap j occupies bytes [(j*C_full + c)*2, ...). The local weight
            // keeps the same layout with C_loc local channels in [q_local; k_local; v_local] order.
            const std::uint64_t C_full = t->shape[1];
            const std::uint64_t C_loc  = C_full / static_cast<std::uint64_t>(world);
            const std::uint64_t taps   = t->shape[0];
            const std::uint64_t r      = static_cast<std::uint64_t>(rank);
            struct Block {
                std::uint64_t src;
                std::uint64_t dst;
                std::uint64_t count;
            };
            const Block blocks[3] = {{r * 1024,         0,    1024}, // q_local channels
                                     {2048 + r * 1024,  1024, 1024}, // k_local channels
                                     {4096 + r * 3072,  2048, 3072}}; // v_local channels
            const char* payload_base = reinterpret_cast<const char*>(payload.data.data());
            char* slot_base          = static_cast<char*>(slot.data);
            for (std::uint64_t j = 0; j < taps; ++j) {
                for (const Block& b : blocks) {
                    const char* s = payload_base + (j * C_full + b.src) * 2u;
                    char* d       = slot_base + (j * C_loc + b.dst) * 2u;
                    const cudaError_t e =
                        cudaMemcpyAsync(d, s, b.count * 2u, cudaMemcpyHostToDevice, stream);
                    if (e != cudaSuccess) {
                        throw std::runtime_error(std::string("tp conv H2D copy failed: ") +
                                                 cudaGetErrorString(e));
                    }
                }
            }
        } else if (p.sharded) {
            const RowSplitGeometry full = row_split_geometry(t->format, t->shape);
            const ShardGeometry src = to_shard(full);
            const void* src_ptr = payload.data.data();
            if (p.role == TpRole::RowK) {
                shard_row_split(src_ptr, src, SplitSpec::RowK, rank, world, slot.data, p.bytes, stream);
            } else {
                const auto ranges = multi_ranges(p.role, rank, world);
                shard_row_ranges(src_ptr, src, ranges, slot.data, p.bytes, stream);
            }
        } else {
            const cudaError_t e = cudaMemcpyAsync(slot.data, payload.data.data(), t->bytes,
                                                  cudaMemcpyHostToDevice, stream);
            if (e != cudaSuccess) {
                throw std::runtime_error(std::string("tp H2D copy failed: ") +
                                         cudaGetErrorString(e));
            }
        }
        device_ptrs[p.index] = slot.data;
        done += p.bytes;
        if (progress != nullptr && progress->callback) {
            progress->callback("tp-weights", done, capacity);
        }
    }
    if (const cudaError_t e = cudaStreamSynchronize(stream); e != cudaSuccess) {
        throw std::runtime_error(std::string("tp materialize sync failed: ") +
                                 cudaGetErrorString(e));
    }
    (void)n_text;
    auto mat = MaterializedArtifact::adopt(std::move(arena), object_count, std::move(device_ptrs),
                                           capacity);
    // The TP device pass only places sharded/replicated TENSORS. initialize() also extracts the
    // frontend host resources (tokenizer, configs); load every non-tensor object so those take_*
    // calls succeed on each rank.
    for (std::size_t i = 0; i < object_count; ++i) {
        if (std::get_if<TensorDescriptor>(&reader.objects()[i]) != nullptr) { continue; }
        const PayloadSpan p = reader.payload(reader.objects()[i]);
        mat.load_resource(ObjectHandle{i}, std::vector<std::byte>(p.data.begin(), p.data.end()));
    }
    return mat;
}

}  // namespace ninfer::targets::qwen3_6_27b::detail
